// Mascara de cpf
$('.cpf').mask('999.999.999-99');
// Mascara de cnpj
$('.cnpj').mask('99.999.999/0001-99');
// Mascara de cep
$('.cep').mask('99.999-999');
// Mascara de telefone
$('.telefone').mask('(99) 99999-9999');
//Mascara de rg
$('.rg').mask('99.999.999');