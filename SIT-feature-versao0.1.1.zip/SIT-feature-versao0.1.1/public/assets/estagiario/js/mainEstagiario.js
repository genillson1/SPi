// let isExpanded = true;

// function navResponsivaEstagiario(){
//     const nav = document.getElementById("navPageEstagiario");
//     const content = document.querySelector(".content")
//     const opPessoais = document.querySelector(".optionPessoais");
//     const opEstagio = document.querySelector(".optionEstagio");
//     const toggleButton = document.getElementById("button");
//     var w = window.innerWidth;

//     if (w >= 825) {
//         nav.style.display = "flex";
//         content.style.marginLeft = "260px"
//         nav.style.width = "250px";
//         opPessoais.style.opacity = "1";
//         opEstagio.style.opacity = "1";
//         toggleButton.src = "assets/estagiario/img/left-arrow.png";
//         isExpanded = true;
//     }else{
//         nav.style.display = "none";
//         content.style.marginLeft = "0"
//     }
// }

// window.addEventListener("resize", navResponsivaEstagiario);

// function toggleNavEstagiario() {

//     const toggleButton = document.getElementById("button");
//     const nav = document.getElementById("navPageEstagiario");
//     const opPessoais = document.querySelector(".optionPessoais");
//     const opEstagio = document.querySelector(".optionEstagio");
//     const content = document.querySelector(".content");

//     if (toggleButton) {
//         if (isExpanded) {
//             nav.style.width = "80px";
//             toggleButton.src = "assets/estagiario/img/right-arrow.png";
//             opPessoais.style.opacity = "0";
//             opEstagio.style.opacity = "0";
//             content.style.marginLeft = "80px"
//         } else {
//             nav.style.width = "250px";
//             toggleButton.src = "assets/estagiario/img/left-arrow.png";
//             opPessoais.style.opacity = "1";
//             opEstagio.style.opacity = "1";
//             content.style.marginLeft = "280px"
//         }
//         isExpanded = !isExpanded;
//     }
// }

// function toggleNavMobile() {
//     let nav = document.getElementById("navPageEstagiario")
//     nav.style.display = nav.style.display == "flex" ? 'none' : 'flex';
// }