let isExpanded = true;

function navResponsiva(){
    const nav = document.getElementById("navPage");
    const content = document.querySelector(".content")
    const opName = document.querySelector(".optionName");
    const opPessoais = document.querySelector(".optionPessoais");
    const opEstagio = document.querySelector(".optionEstagio");
    const opEmpresa = document.querySelector(".optionEmpresa");
    const opCurso = document.querySelector(".optionCurso");
    const opProfessor = document.querySelector(".optionProfessor");
    const toggleButton = document.getElementById("button");
    var w = window.innerWidth;

    if (w >= 825) {
        nav.style.display = "flex";
        content.style.marginLeft = "260px"
        nav.style.width = "250px";
        opName.style.opacity = "1";
        opPessoais.style.opacity = "1";
        opEstagio.style.opacity = "1";
        opCurso.style.opacity = "1";
        opEmpresa.style.opacity = "1";
        opProfessor.style.opacity = "1";
        toggleButton.src = "assets/estagiario/img/left-arrow.png";
        isExpanded = true;
    }else{
        nav.style.display = "none";
        content.style.marginLeft = "0"
    }
}

window.addEventListener("resize", navResponsiva);

function toggleNav() {

    const toggleButton = document.getElementById("button");
    const nav = document.getElementById("navPage");
    const opName = document.querySelector(".optionName");
    const opPessoais = document.querySelector(".optionPessoais");
    const opEstagio = document.querySelector(".optionEstagio");
    const opEmpresa = document.querySelector(".optionEmpresa");
    const opCurso = document.querySelector(".optionCurso");
    const opProfessor = document.querySelector(".optionProfessor");
    const content = document.querySelector(".content");

    if (toggleButton) {
        if (isExpanded) {
            nav.style.width = "80px";
            toggleButton.src = "assets/estagiario/img/right-arrow.png";
            opName.style.opacity = "0";
            opPessoais.style.opacity = "0";
            opEstagio.style.opacity = "0";
            opCurso.style.opacity = "0";
            opEmpresa.style.opacity = "0";
            opProfessor.style.opacity = "0";
            content.style.marginLeft = "80px"
        } else {
            nav.style.width = "250px";
            toggleButton.src = "assets/estagiario/img/left-arrow.png";
            opName.style.opacity = "1";
            opPessoais.style.opacity = "1";
            opEstagio.style.opacity = "1";
            opCurso.style.opacity = "1";
            opEmpresa.style.opacity = "1";
            opProfessor.style.opacity = "1";
            content.style.marginLeft = "280px"
        }
        isExpanded = !isExpanded;
    }
}

function toggleNavMobile() {
    let nav = document.getElementById("navPage")
    nav.style.display = nav.style.display == "flex" ? 'none' : 'flex';
}

// function mostrarFormEstagiario() {

//     let dadosHorarios = document.getElementById("dadosHorarios")
//     dadosHorarios.style.display = "none";

//     let dadosEstagio = document.getElementById("dadosEstagio")
//     dadosEstagio.style.display = "none";

//     let dadosEstagiario = document.getElementById("dadosEstagiario")
//     dadosEstagiario.style.display = 'block';

// }

// function mostrarFormEstagio() {

//     let dadosEstagiario = document.getElementById("dadosEstagiario")
//     dadosEstagiario.style.display = 'none';

//     let dadosHorarios = document.getElementById("dadosHorarios")
//     dadosHorarios.style.display = "none";

//     let dadosEstagio = document.getElementById("dadosEstagio")
//     dadosEstagio.style.display = "block";

// }

// function mostrarHoarios() {

//     let dadosEstagio = document.getElementById("dadosEstagio")
//     dadosEstagio.style.display = "none";

//     let dadosEstagiario = document.getElementById("dadosEstagiario")
//     dadosEstagiario.style.display = 'none';

//     let dadosHorarios = document.getElementById("dadosHorarios")
//     dadosHorarios.style.display = "block";
// }


// let isExpanded = true;

// function navResponsiva(){
   
//     const nav = document.getElementById("navPage");
//     const content = document.querySelector(".content")
//     const opName = document.querySelector(".optionName");
//     const toggleButton = document.getElementById("button");
//     var w = window.innerWidth;

//     if (w >= 825) {
//         nav.style.display = "flex";
//         content.style.marginLeft = "260px"
//         nav.style.width = "250px";
//         opName.style.opacity = "1";
//         toggleButton.src = "/assets/estagiario/img/left-arrow.png";
//         isExpanded = true;
//     }else{
//         nav.style.display = "none";
//         content.style.marginLeft = "0"
//     }
// }

// window.addEventListener("resize", navResponsiva);

// function toggleNav() {

//     const toggleButton = document.getElementById("button");
//     const nav = document.getElementById("navPage");
//     const opName = document.querySelector(".optionName");
//     const content = document.querySelector(".content")

//     if (toggleButton) {
//         if (isExpanded) {
//             nav.style.width = "80px";
//             toggleButton.src = "/assets/estagiario/img/right-arrow.png";
//             opName.style.opacity = "0";
//             content.style.marginLeft = "80px"
//         } else {
//             nav.style.width = "250px";
//             toggleButton.src = "/assets/estagiario/img/left-arrow.png";
//             opName.style.opacity = "1";
//             content.style.marginLeft = "280px"
//         }
//         isExpanded = !isExpanded;
//     }
// }

// function toggleNavMobile() {
//     let nav = document.getElementById("navPage")
//     nav.style.display = nav.style.display == "flex" ? 'none' : 'flex';
// }

function mostrarFormEstagiario() {

    /* let dadosHorarios = document.getElementById("dadosHorarios")
    dadosHorarios.style.display = "none"; */

    let dadosEstagio = document.getElementById("dadosEstagio")
    dadosEstagio.style.display = "none";

    let dadosEstagiario = document.getElementById("dadosEstagiario")
    dadosEstagiario.style.display = 'block';

}

function mostrarFormEstagio() {

    let dadosEstagiario = document.getElementById("dadosEstagiario")
    dadosEstagiario.style.display = 'none';

    /* let dadosHorarios = document.getElementById("dadosHorarios")
    dadosHorarios.style.display = "none"; */

    let dadosEstagio = document.getElementById("dadosEstagio")
    dadosEstagio.style.display = "block";

}

function mostrarHoarios() {

    let dadosEstagio = document.getElementById("dadosEstagio")
    dadosEstagio.style.display = "none";

    let dadosEstagiario = document.getElementById("dadosEstagiario")
    dadosEstagiario.style.display = 'none';

    let dadosHorarios = document.getElementById("dadosHorarios")
    dadosHorarios.style.display = "block";
}

