let isExpanded = true;

function toggleNav() {
    const toggleButton = document.getElementById("button");
    const nav = document.getElementById("navPage");
    const opName = document.querySelector(".optionName");
    const page = document.getElementById("page")
    
    if (toggleButton) {
        if (isExpanded) {
            nav.style.width = "80px";
            toggleButton.src = "assets/estagiario/img/right-arrow.png";
            opName.style.opacity = "0";
            page.style.left = "80px"
        } else {
            nav.style.width = "250px";
            toggleButton.src = "assets/estagiario/img/left-arrow.png";
            opName.style.opacity = "1";
            page.style.left = "250px"
        }
        isExpanded = !isExpanded;    
    } 
}