function deleteModal(venda) {
    let content = `
                                    <input type="hidden" name="id" value="${venda}"/>
                                    `;
    $("#content").html(content);
    $("#modal").modal("show");
}