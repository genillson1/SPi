@include('layouts.pdf.head')

{{-- @include('layout.pdf.header') --}}
<body>
    <main>
        @yield('content')
    </main>
</body>

@include('layouts.pdf.footer')