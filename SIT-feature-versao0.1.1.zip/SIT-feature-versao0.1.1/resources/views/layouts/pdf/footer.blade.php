<footer>
    @yield('footer')
</footer>