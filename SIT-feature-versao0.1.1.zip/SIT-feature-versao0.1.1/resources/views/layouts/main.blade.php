<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
@include('layouts.head')

<body onload="navResponsiva()">

    @include('layouts.header')

    @yield('sidebar')
    <main>
        <section class="d-flex flex-row">


            <div class="content pt-5">
                @yield('content')
            </div>

        </section>
    </main>

    <!-- @include('layouts.footer') -->
    @include('layouts.scripts')

</body>
</html>