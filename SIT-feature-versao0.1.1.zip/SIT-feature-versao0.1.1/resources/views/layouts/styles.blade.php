<!-- CSS Files -->
{{-- <link rel="stylesheet" href="{{ asset('assets/administrativo/css/bootstrap.min.css') }}"> --}}
<link rel="stylesheet" href="{{ asset('assets/bootstrap/css/bootstrap.min.css.map') }}">
<link rel="stylesheet" href="{{ asset('assets/bootstrap/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/administrativo/css/atlantis.min.css') }}">

<!-- CSS Fontawesome -->
<link rel="stylesheet" href="{{ asset('assets/common/fontawesome/css/fontawesome.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/common/fontawesome/css/brands.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/common/fontawesome/css/solid.min.css') }}">

<!-- CSS Just for demo purpose, don't include it in your project -->
<link rel="stylesheet" href="{{ asset('assets/administrativo/css/demo.css') }}">

{{-- <link href="{{ asset('assets/administrativo/css/bootstrap.min.css') }}" rel="stylesheet"> --}}
<link href="{{ asset('assets/estagiario/css/style.css') }}" rel="stylesheet">
<link href="{{ asset('assets/estagiario/css/termo_styles.css') }}" rel="stylesheet">
{{-- <link href="{{ asset('assets/estagiario/css/style_copy.css')}}" rel="stylesheet"> --}}

{{-- <link href="/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/css/style.css" rel="stylesheet">
<link href="/css/termo_styles.css" rel="stylesheet">
<link rel="icon" href="/img/mortarboard-fill.svg"> --}}
@stack('styles')