<!--   Core JS Files   -->
<script src="{{ asset('assets/administrativo/js/core/jquery.3.2.1.min.js') }}"></script>
<script src="{{ asset('assets/administrativo/js/core/popper.min.js') }}"></script>
{{-- <script src="{{ asset('assets/administrativo/js/core/bootstrap.min.js') }}"></script> --}}
{{-- <script src="{{ asset('assets/bootstrap/js/bootstrap.min.js.map') }}"></script> --}}
<script src="{{ asset('assets/estagiario/js/jquery.mask.min.js') }}"></script>

<!-- jQuery UI -->
<script src="{{ asset('assets/administrativo/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js') }}"></script> 
<script src="{{ asset('assets/administrativo/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js') }}"></script>

<!-- jQuery Scrollbar -->
<script src="{{ asset('assets/administrativo/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js') }}"></script>

<!-- Atlantis JS -->
<script src="{{ asset('assets/administrativo/js/atlantis.min.js') }}"></script>

<script src="{{ asset('assets/bootstrap/js/bootstrap.min.js') }}"></script>
{{-- <script src="{{ asset('assets/bootstrap/js/bootstrap.bundle.min.js.map') }}"></script> --}}
{{-- <script src="{{ asset('assets/bootstrap/js/bootstrap.bundle.min.js.map') }}"></script> --}}
<script src="{{ asset('assets/estagiario/js/main.js') }}"></script>
{{-- <script src="{{ asset('assets/estagiario/js/mainEstagiario.js') }}"></script> --}}
{{-- <script src="{{ asset('assets/estagiario/js/script.js') }}"></script> --}}

@stack('scripts')