<header class="d-flex flex-row p-2 align-items-center justify-content-between">
    @yield('header')
    @yield('navbar')
</header>