<footer>
    @yield('footer') 2023
</footer>