<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>E-Mail de Verificação</title>
</head>
<body>
    <div class="card">
        <div class="card-header">
            Verificação de E-Mail
        </div>
        <div class="card-body">
            <h5 class="card-title">Olá {{ $user->nome }}</h5>
            <p class="card-text">Verifique seu E-Mail para ter acesso ao sistema.</p>
            <a href="{{route('login.verification', $user->id)}}" class="btn btn-primary">Verificar E-Mail</a>
        </div>
    </div>
</body>
</html>