@extends('layouts.main')

@push('styles')
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
@endpush

@section('header')
    @include('administrativo.build.navbar')
@endsection


@section('content')
    <div class="container">
        <form action="{{ route('login.store') }}" method="post">
            @csrf
            <div class="form-group">
                <label for="">Nome: </label>
                <input type="text" name="nome" placeholder="Digite seu nome">
            </div>
            <div class="form-group">
                <label for="">E-Mail:</label>
                <input type="email" name="email" placeholder="Digite seu e-mail">
            </div>
            <div class="form-group">
                <label for="">Senha:</label>
                <input type="password" name="password" placeholder="Digite uma senha">
            </div>
            <div class="form-group">
                <label for="">Confirmar senha: </label>
                <input type="password" name="confirm_password" placeholder="Confirme a senha">
            </div>
            <input type="submit" value="Cadastrar">
        </form>
    
        @if (session('session'))
            <div class="alert alert-success" role="alert">
                <p>{{ session('session') }}</p>
            </div>
        @endif

        @if ($errors->first('error'))
            <div class="alert alert-danger" role="alert">
                <p>{{ $errors->first('error') }}</p>
            </div>
        @endif
    </div>
@endsection

@push('scripts')
    
@endpush