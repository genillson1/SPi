<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="{{ asset('/assets/estagiario/css/login.css')}}">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ env('APP_NAME') }}</title>
</head>
<body>
    <main>
        <div id='title'>
            <div>
                <h1>SIT</h1>
                <h2>Sistema Interno de Talentos</h2>
            </div>
            <div>
                <img src="{{ asset('assets/estagiario/img/logo_marca.png') }}" alt="Logo IFSertão">
            </div>
        </div>
        <section>
            <p>Cadastre-se</p>
            <form action="{{ route('login.store') }}" method="post">
                @csrf
                <div class="form-group">
                    <!-- <label for="">Nome: </label> -->
                    <input type="text" name="nome" placeholder="Digite seu nome">
                </div>
                <div class="form-group">
                    <!-- <label for="">E-Mail:</label> -->
                    <input type="email" name="email" placeholder="Digite seu e-mail">
                </div>
                <div class="form-group">
                    <!-- <label for="">Senha:</label> -->
                    <input type="password" name="password" placeholder="Digite uma senha">
                </div>
                <div class="form-group">
                    <!-- <label for="">Confirmar senha: </label> -->
                    <input type="password" name="confirm_password" placeholder="Confirme a senha">
                </div>
                <input type="submit" value="Cadastrar">
                <p id='bottomText'>Já possui cadastro? <a href="{{ route('login.index') }}">Fazer Login</a></p>
            </form>
            
        </section>
    </main>
</body>
</html>