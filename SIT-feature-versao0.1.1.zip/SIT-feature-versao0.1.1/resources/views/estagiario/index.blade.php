@extends('layouts.main')

@push('styles')
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
@endpush

@section('header')
    @include('estagiario.build.navbar')
@endsection

@section('sidebar')
    @include('estagiario.build.sidebar')
@endsection

@section('content')

<div class="container">

    <div class="d-flex">
        <h4 class="page-title">Estagiario</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="{{ route('estagiario.index') }}">
                    <i class="fas fa-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="fas fa-chevron-right"></i>
            </li>
            <li class="nav-item">
                <a href="{{ route('estagiario.index') }}">Inicio</a>
            </li>
        </ul>
    </div>

    <div class="card cartao">
        <div class="card-header">
            <div class="d-flex align-items-center">
                <div class="row w-100 align-items-center justify-content-between">
                    <h4 class="card-title col-md-5">Meus Estagios</h4>    
                </div>
            </div>
        </div>
        <div class="card-body">

            <div class="table-resposive">
                <table id="add-row" class="display table table-striped table-hover">
                    <thead class="text-center">
                        <th>Nome</th>
                        <th>Curso</th>
                        <th>Concedente</th>
                        <th>Orientador(a)</th>
                        <th>Situação</th>
                        <th>Ações</th>
                    </thead>
            
                    <tbody>
                        @foreach ($estagios as $estagio)
                            <tr class="text-center">
                                <td>{{ $estagio->nome_aluno }}</td>
                                <td>{{ $estagio->nome_curso }}</td>
                                <td>{{ $estagio->nome_empresa }}</td>
                                <td>{{ $estagio->nome_orientador }}</td>
                                @if ($estagio->status == '1')
                                    <td>Em Analise</td>
                                @endif
                                @if ($estagio->status == '2')
                                    <td>Esperando assinatura</td>
                                @endif
                                @if ($estagio->status == '3')
                                    <td>Aprovado, Em andamento</td>
                                @endif
                                <td>
                                    <a href="{{ route('estagiario.dados.estagio.show', $estagio->id) }}" data-toggle="tooltip" title="Visializar"
                                        class="btn btn-link btn-lg"
                                        data-original-title="Edit Task">
                                        <i class="fas fa-eye"></i>
                                    </a>

                                    <a href="{{ route('estagiario.dados.estagio.edit', $estagio->id) }}"
                                        data-toggle="tooltip" title="Editar"
                                        class="btn btn-link btn-lg"
                                        data-original-title="Edit Task">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <a href="{{ route('estagiario.dados.pdf', $estagio->id) }}"
                                        data-toggle="tooltip" title="PDF"
                                        class="btn btn-link btn-lg"
                                        data-original-title="Gerar pdf">
                                        <i class="fas fa-file"></i>
                                    </a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

@endsection

@push('scripts')
<script src="{{ asset('assets/administrativo/js/plugin/datatables/datatables.min.js') }}"></script>
<script src="{{ asset('assets/administrativo/js/modal.js') }}"></script>
<script>
    $(document).ready(function() {
        $('#add-row').DataTable({
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.4/i18n/pt-BR.json',
            },
        });
    });

    var action =
        '<td> <div class="form-button-action"> <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-primary btn-lg" data-original-title="Edit Task"> <i class="fa fa-edit"></i> </button> <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-danger" data-original-title="Remove"> <i class="fa fa-times"></i> </button> </div> </td>';

    $('#addRowButton').click(function() {
        $('#add-row').dataTable().fnAddData([
            $("#addName").val(),
            $("#addPosition").val(),
            $("#addOffice").val(),
            action
        ]);
        $('#addRowModal').modal('hide');

    });
</script>
@endpush