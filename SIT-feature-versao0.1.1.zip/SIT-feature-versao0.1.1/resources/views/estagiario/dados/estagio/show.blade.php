@extends('layout.main')

@push('styles')
@endpush

@section('header')
    @include('gestao.buid.navbar')
@endsection

@section('sidebar')
    @include('gestao.build.sidebar')
@endsection

@section('content')
    
@endsection

@push('scripts')
    
@endpush