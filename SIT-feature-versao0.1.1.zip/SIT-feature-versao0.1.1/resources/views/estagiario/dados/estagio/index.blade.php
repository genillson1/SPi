@extends('layout.main')

@push('styles')
@endpush

@section('header')
    @include('estagiario.buid.navbar')
@endsection

@section('sidebar')
    @include('estagiario.build.sidebar')
@endsection

@section('content')
    
@endsection

@push('scripts')
    
@endpush