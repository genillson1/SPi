@extends('layouts.main')

@push('styles')
@endpush

@section('header')
    @include('estagiario.build.navbar')
@endsection

@section('sidebar')
    @include('estagiario.build.sidebar')
@endsection

@section('content')
@if (Auth::user())
@else
    <h1>Usuario não logado</h1>
@endif
<div class="container">
    <div class="d-flex">
        <h4 class="page-title">Estagiario</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="{{ route('estagiario.index') }}">
                    <i class="fas fa-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="fas fa-chevron-right"></i>
            </li>
            <li class="nav-item">
                <a href="{{ route('estagiario.index') }}">Estagiario</a>
            </li>
            <li class="separator">
                <i class="fas fa-chevron-right"></i>
            </li>
            <li class="nav-item">
                <a href="{{ route('estagiario.index') }}">Dados</a>
            </li>
            <li class="separator">
                <i class="fas fa-chevron-right"></i>
            </li>
            <li class="nav-item">
                <a href="{{ route('estagiario.index') }}">Pessoais</a>
            </li>
            <li class="separator">
                <i class="fas fa-chevron-right"></i>
            </li>
            <li class="nav-item">
                <a href="{{ route('estagiario.dados.estagio.create') }}">Editar</a>
            </li>
        </ul>
    </div>
    <form action="{{ route('estagiario.dados.pessoais.update') }}" method="post">
        @method('PUT')
        @csrf
        @csrf
        @if ($errors->first('error'))
        <div class=" alert alert-warning" role="alert">
            {{ $errors->first('error') }}
            Preencha todos os campos
        </div>
        @endif

        @if (session('session'))
        <div class="alert alert-success" role="alert">
            {{ session('session') }}
        </div>
        @endif

        <div id="dadosEstagiario">
        
            <h5>Informações do estagiário</h5>

            <div class="container_inputs mt-3">

                <div class="m-3 item1">
                    <label class="form-label" for="nome">Nome completo:</label>
                    <input type="text" name="nome" id="nome" class="form-control rounded-0 input_longo" placeholder="Digite seu nome completo" value="{{ $aluno->nome }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="data-de-nascimento">Data de nascimento:</label>
                    <input type="date" name="data_nascimento" id="data-de-nascimento" class="form-control rounded-0 input_menor" placeholder="Número RG" value="{{ $aluno->data_nascimento }}" disabled>
                </div>

                <div class="m-3">
                    <label class="form-label" for="cpf">CPF:</label>
                    <input type="text" name="cpf" id="cpf" class="form-control rounded-0 input_menor cpf" placeholder="Digite o número do seu CPF" value="{{ $aluno->cpf }}" disabled>
                </div>

                <div class="m-3">
                    <label class="form-label" for="rg">RG:</label>
                    <input type="text" name="rg" id="rg" class="rg form-control rounded-0 input_menor" placeholder="Digite o número do RG" value="{{ $aluno->rg }}">
                </div>


                <div class="m-3">
                    <label class="form-label" for="orgao-expedidor">Orgão expedidor:</label>
                    <input type="text" name="org_ex" id="orgao-expedidor" class="form-control rounded-0 input_menor" placeholder="Orgão Expedidor" value="{{ $aluno->org_ex }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="cep">CEP:</label>
                    <input type="text" name="cep" id="cep" class="cep form-control rounded-0 input_menor" placeholder="Digite o CEP" value="{{ $endereco->cep }}">
                </div>

                <div class="m-3 item1">
                    <label class="form-label" for="rua">Logradouro:</label>
                    <input type="text" name="logradouro" id="rua" class="form-control rounded-0 input_longo" placeholder="Avenida, Rua, Travessa, etc..." value="{{ $endereco->logradouro }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="numero">Número do endereço:</label>
                    <input type="text" name="numero" id="numero" class="form-control rounded-0 input_menor" placeholder="Digite o número do seu endereço" value="{{ $endereco->numero }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="bairro">Bairro:</label>
                    <input type="text" name="bairro" id="bairro" class="form-control rounded-0 input_menor" placeholder="Digite o nome do bairro" value="{{ $endereco->bairro }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="cidade">Cidade:</label>
                    <input type="text" name="cidade" id="cidade" class="form-control rounded-0 input_menor" placeholder="Digite o nome da cidade" value="{{ $endereco->cidade }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="uf">UF (Estado):</label>
                    <select name="uf" id="uf" class="form-select  rounded-0 input_menor">
                        <option value="null" selected>Selecione o estado</option>
                        <option value="PE">PE</option>
                        <option value="BA">BA</option>
                    </select>
                </div>

                <div class="m-3">
                    <label class="form-label" for="telefone">Seu celular:</label>
                    <input type="text" name="telefone" id="telefone" class="telefone form-control rounded-0 input_menor" placeholder="Digite o número de seu celular" value="{{ $aluno->telefone }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="email">Seu e-mail:</label>
                    <input type="email" name="email" id="email" class="form-control rounded-0 input_menor" value="{{ Auth::user()->email }}" disabled>
                </div>
            
        </div>

            <div class="mt-3 d-flex flex-row float-end mt-3 me-1 ms-1">
                <button type="submit" class="btn btn-success botoes me-2">Atualizar</button>
            </div>

        </div>
    </form>
</div>
@endsection

@push('scripts')
{{-- Criação de Mascaras para CPF e Valor --}}
<script src="{{ asset('assets/estagiario/js/masks.js') }}"></script>

@endpush