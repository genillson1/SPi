@extends('layouts.main')

@push('styles')
@endpush

@section('header')
    @include('estagiario.build.navbar')
@endsection

@section('sidebar')
    @include('estagiario.build.sidebar')
@endsection

@section('content')
    @if (Auth::user())
    @else
        <h1>Usuario não logado</h1>
    @endif
<div class="container">

    <div class="d-flex">
        <h4 class="page-title">Estagiario</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="{{ route('estagiario.index') }}">
                    <i class="fas fa-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="fas fa-chevron-right"></i>
            </li>
            <li class="nav-item">
                <a href="{{ route('estagiario.index') }}">Estagiario</a>
            </li>
            <li class="separator">
                <i class="fas fa-chevron-right"></i>
            </li>
            <li class="nav-item">
                <a href="{{ route('estagiario.index') }}">Dados</a>
            </li>
            <li class="separator">
                <i class="fas fa-chevron-right"></i>
            </li>
            <li class="nav-item">
                <a href="{{ route('estagiario.index') }}">pessoais</a>
            </li>
            <li class="separator">
                <i class="fas fa-chevron-right"></i>
            </li>
            <li class="nav-item">
                <a href="{{ route('estagiario.dados.estagio.create') }}">Cadastro</a>
            </li>
        </ul>
    </div>

    <form action="{{ route('estagiario.dados.pessoais.store') }}" method="post">
        @csrf
        @if ($errors->first('error'))
        <div class=" alert alert-warning" role="alert">
            {{ $errors->first('error') }}
            Preencha todos os campos
        </div>
        @endif

        @if (session('session'))
        <div class="alert alert-success" role="alert">
            {{ session('session') }}
        </div>
        @endif

        <div id="dadosEstagiario">
        
            <h5>Informações do estagiário</h5>

            <div class="container_inputs mt-3">

                <div class="m-3 item1">
                    <label class="form-label" for="nome">Nome completo:</label>
                    <input type="text" name="nome" id="nome" class="form-control rounded-0 input_longo" placeholder="Digite o seu nome completo">
                </div>

                <div class="m-3">
                    <label class="form-label" for="data-de-nascimento">Data de nascimento:</label>
                    <input type="date" name="data_nascimento" id="data-de-nascimento" class="form-control rounded-0 input_menor">
                </div>

                <div class="m-3">
                    <label class="form-label" for="cpf">CPF:</label>
                    <input type="text" name="cpf" id="cpf" class="form-control rounded-0 input_menor cpf" placeholder="Digite o número do seu CPF">
                </div>

                <div class="m-3">
                    <label class="form-label" for="rg">RG:</label>
                    <input type="text" name="rg" id="rg" class="form-control rounded-0 input_menor rg" placeholder="Digite o número do seu RG">
                </div>


                <div class="m-3">
                    <label class="form-label" for="orgao-expedidor">Orgão expedidor:</label>
                    <input type="text" name="org_ex" id="orgao-expedidor" class="form-control rounded-0 input_menor" placeholder="Digite o Orgão Expedidor">

                </div>

                <div class="m-3">
                    <label class="form-label" for="cep">CEP:</label>
                    <input type="text" name="cep" id="cep" class="form-control rounded-0 input_menor cep" placeholder="Digite o CEP">
                </div>

                <div class="m-3 item1">
                    <label class="form-label" for="rua">Logradouro</label>
                    <input type="text" name="logradouro" id="rua" class="form-control rounded-0 input_longo" placeholder="Avenida, Rua, Travessa, etc...">
                </div>

                <div class="m-3">
                    <label class="form-label" for="numero">Número do endereço:</label>
                    <input type="text" name="numero" id="numero" class="form-control rounded-0 input_menor" placeholder="Digite o número do endereço">
                </div>

                <div class="m-3">
                    <label class="form-label" for="bairro">Bairro:</label>
                    <input type="text" name="bairro" id="bairro" class="form-control rounded-0 input_menor" placeholder="Digite o nome do bairro">
                </div>

                <div class="m-3">
                    <label class="form-label" for="cidade">Cidade:</label>
                    <input type="text" name="cidade" id="cidade" class="form-control rounded-0 input_menor" placeholder="Digite o nome da cidade">
                </div>

                <div class="m-3">
                    <label class="form-label" for="uf">UF (Estado):</label>
                    <select name="uf" id="uf" class="form-select  rounded-0 input_menor">
                        <option value="null" selected>Selecione o estado</option>
                        <option value="PE">PE</option>
                        <option value="BA">BA</option>
                    </select>
                </div>

                <div class="m-3">
                    <label class="form-label" for="telefone">Seu celular:</label>
                    <input type="text" name="telefone" id="telefone" class="form-control rounded-0 input_menor telefone" placeholder="Digite o número de seu celular">
                </div>

                <div class="m-3">
                    <label class="form-label" for="email">Seu e-mail:</label>
                    <input type="email" name="email" id="email" class="form-control rounded-0 input_menor" placeholder="Digite o e-mail institucional" value="{{ Auth::user()->email }}">
                </div>

            </div>

            <div class="mt-3 d-flex flex-row float-end mt-3 me-1 ms-1">
                <button type="submit" class="btn btn-success botoes me-2">Cadastrar</button>
            </div>

        </div>
    </form>
</div>
@endsection

@push('scripts')
    {{-- Criação de Mascaras para CPF e Valor --}}
    <script src="{{ asset('assets/estagiario/js/masks.js') }}"></script>
    
@endpush