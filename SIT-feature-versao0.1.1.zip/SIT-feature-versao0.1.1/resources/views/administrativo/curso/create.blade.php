@extends('layouts.main')

@push('styles')
@endpush

@section('header')
    @include('administrativo.build.navbar')
@endsection

@php
    $page = 'curso';
@endphp

@section('sidebar')
    @include('administrativo.build.sidebar')
@endsection

@section('content')
<div class="container">

    <div class="d-flex">
        <h4 class="page-title">Administrativo</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="{{ route('administrativo.index') }}">
                    <i class="fas fa-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="fas fa-chevron-right"></i>
            </li>
            <li class="nav-item">
                <a href="{{ route('administrativo.index') }}">Cursos</a>
            </li>
            <li class="separator">
                <i class="fas fa-chevron-right"></i>
            </li>
            <li class="nav-item">
                <a href="#">Cadastro</a>
            </li>
        </ul>   
    </div>

    <form action="{{ route('administrativo.curso.store') }}" method="post">
        @csrf
        @if ($errors->first('error'))
            <div class=" alert alert-warning" role="alert">
                {{ $errors->first('error') }}
                Preencha todos os campos
            </div>
        @endif

        @if (session('session'))
            <div class="alert alert-success" role="alert">
                {{ session('session') }}
            </div>
        @endif

        <div>

            <h4>Cadastro de curso</h4>
    
            <div class="container_inputs">
    
                <div class="m-3">
                    <label class="form-label" for="nome">Nome do curso:</label>
                    <input type="text" name="nome" id="nome" class="form-control rounded-0 input_longo" placeholder="Digite o nome curso">
                </div>
    
                <div class="m-3">
                    <label class="form-label" for="tipo">Modalidade do curso</label>
                    <select name="modalidade" id="tipo" class="form-select rounded-0 input_longo">
                        <option value="null">Selecione a modalidade</option>
                        <option value="Bacharelado">Bacharelado</option>
                        <option value="Licenciatura">Licenciatura</option>
                        <option value="Tecnologos">Tecnólogos</option>
                        <option value="Sequenciais">Sequenciais</option>
                    </select>
                </div>
    
                {{-- <div class="m-3">
                    <label class="form-label" for="campus">Campus autorizado a ofertar o curso:</label>
                    <input type="text" name="campus" id="campus" class="form-control rounded-0 input_longo" placeholder="Digite o nome do campus">
                </div> --}}
    
                <div class="m-3">
                    <label class="form-label" for="carga-horaria">Periodo de referencia de estagio:</label>
                    <input type="text" name="periodo" id="carga-horaria" class="form-control rounded-0 input_longo" placeholder="Digite o periodo">
                </div>

                {{-- <div class="m-3">
                    <label class="form-label" for="carga-horaria">Carga Horária:</label>
                    <input type="number" name="carga-horaria" id="carga-horaria" class="form-control rounded-0 input_menor" placeholder="Digite carga horária">
                </div>
    
                <div class="m-3">
                    <label class="form-label" for="duracao">Duração:</label>
                    <input type="number" name="duracao" id="duracao" class="form-control rounded-0 input_menor" placeholder="Digite a duração em anos">
                </div> --}}
    
            </div>
    
            <button type="submit" class="btn btn-success mt-3 float-end botoes">Cadastrar</button>
    
        </div>
    </form>
</div>
@endsection

@push('scripts')
    
@endpush