@extends('layouts.main')

@push('styles')
@endpush

@section('header')
    @include('administrativo.build.navbar')
@endsection

@section('sidebar')
    @include('administrativo.build.sidebar')
@endsection

@section('content')
<div class="container">

    <div class="d-flex">
        <h4 class="page-title">Administrativo</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="{{ route('administrativo.index') }}">
                    <i class="fas fa-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="fas fa-chevron-right"></i>
            </li>
            <li class="nav-item">
                <a href="{{ route('administrativo.estudante.index') }}">Estudante</a>
            </li>
            <li class="separator">
                <i class="fas fa-chevron-right"></i>
            </li>
            <li class="nav-item">
                <a href="#">Editar</a>
            </li>
        </ul>
    </div>
    <form action="{{ route('administrativo.estudante.update', $estagio->id) }}" method="post">
        @method('PUT')
        @csrf
        @if ($errors->first('error'))
        <div class=" alert alert-warning" role="alert">
            {{ $errors->first('error') }}
            Preencha todos os campos
        </div>
        @endif

        @if (session('session'))
        <div class="alert alert-success" role="alert">
            {{ session('session') }}
        </div>
        @endif

        <div id="dadosEstagiario">
        
            <h5>Informações do estagiário</h5>

            <div class="container_inputs mt-3">

                <div class="m-3 item1">
                    <label class="form-label" for="nome">Nome completo:</label>
                    <input type="text" name="nome" id="nome" class="form-control rounded-0 input_longo" placeholder="Digite o nome completo" value="{{ $aluno->nome }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="data-de-nascimento">Data de nascimento:</label>
                    <input type="date" name="data_nascimento" id="data-de-nascimento" class="form-control rounded-0 input_menor" placeholder="Número RG" value="{{ $aluno->data_nascimento }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="cpf">CPF:</label>
                    <input type="text" name="cpf" id="cpf" class="form-control rounded-0 input_menor cpf" placeholder="Digite o número do CPF" value="{{ $aluno->cpf }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="rg">RG:</label>
                    <input type="text" name="rg" id="rg" class="form-control rounded-0 input_menor rg" placeholder="Digite o número do RG" value="{{ $aluno->rg }}">
                </div>


                <div class="m-3">
                    <label class="form-label" for="orgao-expedidor">Orgão expedidor:</label>
                    <input type="text" name="org_ex" id="orgao-expedidor" class="form-control rounded-0 input_menor" placeholder="Digite o Orgão Expedidor" value="{{ $aluno->org_ex }}">

                </div>

                <div class="m-3">
                    <label class="form-label" for="cep">CEP:</label>
                    <input type="text" name="cep" id="cep" class="form-control rounded-0 input_menor cep" placeholder="Digite o CEP" value="{{ $endereco->cep }}">
                </div>

                <div class="m-3 item1">
                    <label class="form-label" for="rua">Logradouro</label>
                    <input type="text" name="logradouro" id="rua" class="form-control rounded-0 input_longo" placeholder="Avenida, Rua, Travessa, etc..." value="{{ $endereco->logradouro }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="numero">Número do endereço:</label>
                    <input type="text" name="numero" id="numero" class="form-control rounded-0 input_menor" placeholder="Digite o número do endereço" value="{{ $endereco->numero }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="bairro">Bairro:</label>
                    <input type="text" name="bairro" id="bairro" class="form-control rounded-0 input_menor" placeholder="Digite o nome do bairro" value="{{ $endereco->bairro }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="cidade">Cidade:</label>
                    <input type="text" name="cidade" id="cidade" class="form-control rounded-0 input_menor" placeholder="Digite o nome da cidade" value="{{ $endereco->cidade }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="uf">UF (Estado):</label>
                    <select name="uf" id="uf" class="form-select  rounded-0 input_menor">
                        <option value="{{ $endereco->uf }}" selected>{{ $endereco->uf }}</option>
                        <option value="PE">PE</option>
                        <option value="BA">BA</option>
                    </select>
                </div>

                <div class="m-3">
                    <label class="form-label" for="telefone">Seu celular:</label>
                    <input type="text" name="telefone" id="telefone" class="form-control rounded-0 input_menor telefone" placeholder="Digite o número de seu celular" value="{{ $aluno->telefone }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="email">Seu e-mail:</label>
                    <input type="email" name="email" id="email" class="form-control rounded-0 input_menor" placeholder="Digite o e-mail institucional" value="{{ $aluno->email }}" disabled>
                </div>

            </div>

            <div class="mt-3 d-flex flex-row float-end mt-3 me-1 ms-1">
                <button type="submit" class="btn btn-success botoes me-2">Atualizar</button>
                <button onclick="mostrarFormEstagio()" type="button" class="btn btn-outline-secondary d-flex align-items-center">
                    <span>Próximo</span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-right" viewBox="0 0 16 16">
                        <path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z" />
                    </svg>
                </button>
            </div>

        </div>

        <div class="mt-3" id="dadosEstagio">

            <h5>Informações do estágio</h5>

            <div class="container_inputs">

                <div class="m-3">
                    <label class="form-label" for="seu-curso">Seu curso:</label>
                    <div class="d-flex flex-row input_menor">
                        <select name="curso_id" class="form-select rounded-0 input_menor" id="seu-curso">
                            <option value="{{ $curso->id }}">$curso->nome</option>
                            @foreach ($cursos as $curso)
                            <option value="{{ $curso->id }}">{{ $curso->nome }}</option>
                            @endforeach
                        </select>
                        {{-- <a href="/administrativo/curso/create" class="btn btn-success rounded-1 ms-2" title="Cadastrar curso">+</a> --}}
                    </div>
                </div>

                <div class="m-3">
                    <label class="form-label" for="periodo">Período de referencia:</label>
                    <select name="periodo_curso" class="form-select  rounded-0 input_menor" id="periodo">
                        <option value="{{ $estagio->periodo_curso }}" selected>{{ $estagio->periodo_curso }}º Período</option>
                        <option value="1">1º período</option>
                        <option value="2">2º período</option>
                        <option value="3">3º período</option>
                        <option value="4">4º período</option>
                        <option value="5">5º período</option>
                        <option value="6">6º período</option>
                        <option value="7">7º período</option>
                        <option value="8">8º período</option>
                    </select>
                </div>

                <div class="m-3">
                    <label class="form-label" for="empresa-concedente">Empresa concedente:</label>
                    <div class="d-flex flex-row input_menor">
                        <select name="empresa_id" class="form-select rounded-0" id="empresa-concedente">
                            <option value="{{ $empresa->id }}">{{ $empresa->nome }}</option>
                            @foreach ($empresas as $empresa)
                            <option value="{{ $empresa->id }}">{{ $empresa->nome }}</option>
                            @endforeach
                        </select>
                        {{-- <a href="/administrativo/empresa/create" class="btn btn-success rounded-1 ms-2" title="Cadastrar empresa">+</a> --}}
                    </div>
                </div>

                <div class="m-3">
                    <label class="form-label" for="data-de-inicio">Data de início:</label>
                    <input type="date" name="data_inicio" id="data-de-inicio" class="form-control rounded-0 input_menor" value="{{ $estagio->data_inicio }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="data-prevista-para-termino">Data prevista para término:</label>
                    <input type="date" name="data-prevista-para-termino" id="data-prevista-para-termino" class="form-control rounded-0 input_menor" value="{{ $estagio->data_termino }}" disabled>
                </div>

                <div class="m-3">
                    <label class="form-label" for="duracao">Duração:</label>
                    <input type="text" name="duracao" id="duracao" class="form-control rounded-0 input_menor" placeholder="Informe a duração em horas" value="{{ $estagio->duracao }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="professor-orientador">Professor(a) orientador(a)</label>
                    <select name="orientador_id" class="form-select rounded-0 input_longo" id="professor-orientador">
                        <option value="{{ $orientador->id }}" selected>{{ $orientador->nome }}</option>
                        @foreach ($orientadores as $orientador)
                        <option value="{{ $orientador->id }}">{{ $orientador->nome }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="m-3">
                    <label class="form-label" for="nome_supervisor">Nome Supervisor:</label>
                    <input type="text" name="nome_supervisor" id="nome_supervisor" class="form-control rounded-0 input_menor" placeholder="Informe o nome do supervisor" value="{{ $estagio->nome_supervisor }}">
                </div>
                <div class="m-3">
                    <label class="form-label" for="cargo_supervisor">Cargo Supervisor:</label>
                    <input type="text" name="cargo_supervisor" id="cargo_supervisor" class="form-control rounded-0 input_menor" placeholder="Informe o cargo do supervisor" value="{{ $estagio->cargo_supervisor }}">
                </div>
                <div class="m-3">
                    <label class="form-label" for="email_supervisor">E-mail Supervisor:</label>
                    <input type="email" name="email_supervisor" id="email_supervisor" class="form-control rounded-0 input_menor" placeholder="Informe o email do supervisor" value="{{ $estagio->email_supervisor }}">
                </div>
                <div class="m-3">
                    <label class="form-label" for="telefone_supervisor">Telefone Supervisor:</label>
                    <input type="text" name="telefone_supervisor" id="telefone_supervisor" class="form-control rounded-0 input_menor telefone" placeholder="Informe o telefone do supervisor" value="{{ $estagio->telefone_supervisor }}">
                </div>

            </div>

            <div class="d-flex flex-row justify-content-between mt-3">

                <button onclick="mostrarFormEstagiario()" type="button" class="btn btn-outline-secondary d-flex align-items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-left" viewBox="0 0 16 16">
                        <path fill-rule="evenodd" d="M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z" />
                    </svg>
                    <span>Voltar</span>
                </button>

                <button type="submit" class="btn btn-success botoes botoes">Atualizar</button>

            </div>

        </div>

    </form>
</div>
@endsection

@push('scripts')
    
@endpush