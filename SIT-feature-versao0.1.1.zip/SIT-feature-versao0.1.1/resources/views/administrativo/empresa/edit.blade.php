@extends('layouts.main')

@push('styles')
@endpush

@php
    $page = 'empresa';
@endphp

@section('header')
    @include('administrativo.build.navbar')
@endsection

@section('sidebar')
    @include('administrativo.build.sidebar')
@endsection

@section('content')
<div class="container">

    <div class="d-flex">
        <h4 class="page-title">Administrativo</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="{{ route('administrativo.index') }}">
                    <i class="fas fa-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="fas fa-chevron-right"></i>
            </li>
            <li class="nav-item">
                <a href="{{ route('administrativo.empresa.index') }}">Empresas</a>
            </li>
            <li class="separator">
                <i class="fas fa-chevron-right"></i>
            </li>
            <li class="nav-item">
                <a href="#">Editar</a>
            </li>
        </ul>
    </div>
    <form action="{{ route('administrativo.empresa.update', $empresa->id) }}" method="post">
        @csrf
        @method('PUT')
        @if ($errors->first('errorEndereco'))
        <div class="alert alert-warning">Preencha todos os campos de endereco</div>
        @else 
            @if ($errors->first('errorEmpresa'))
                <div class="alert alert-warning">Preencha todos os campos de empresa</div>
            @else
                @if ($errors->first('errorRepresentante'))
                    <div class="alert alert-warning">Preencha todos os campos de representante</div>
                @endif
            @endif
        @endif

        @if (session('session'))
            <div class="alert alert-success" role="alert">
                {{ session('session') }}
            </div>
        @endif
        
        <div>

            <h4>Informações da empresa concedente</h4>
    
            <div class="container_inputs">
    
                <div class="m-3">
                    <label class="form-label" for="nome-da-empresa">Nome:</label>
                    <input type="text" name="nome" id="nome-da-empresa" class="form-control rounded-0 input_longo" placeholder="Digite o nome da empresa" value="{{ $empresa->nome }}">
                </div>
    
                <div class="m-3">
                    <label class="form-label" for="cnpj">CNPJ:</label>
                    <input type="text" name="cnpj" id="cnpj" class="form-control rounded-0 input_menor" placeholder="Digite o CNPJ" value="{{ $empresa->cnpj }}">
                </div>
    
                <div class="m-3">
                    <label class="form-label" for="natureza-juridica-cpf">Natureza jurídica:</label>
                    <input type="text" name="natureza_juridica" id="natureza-juridica-cpf" class="form-control rounded-0 input_longo" placeholder="Natureza da empresa" value="{{ $empresa->natureza_juridica }}">
                </div>
    
                <div class="m-3">
                    <label class="form-label" for="representador">Representada por:</label>
                    <input type="text" name="nome_representante" id="representador" class="form-control rounded-0 input_longo" placeholder="Digite o nome do(a) representante da empresa"value="{{ $representante->nome_representante }}">
                </div>
    
                <div class="m-3">
                    <label class="form-label" for="cargo-do-representante">Cargo do(a) representante da empresa:</label>
                    <input type="text" name="cargo_representante" id="cargo-do-representante" class="form-control rounded-0 input_longo" placeholder="Digite o cargo do(a) representante da empresa" value="{{ $representante->cargo_representante }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="cpf-do-representante">CPF do(a) Representante:</label>
                    <input type="text" name="cpf_representante" id="cpf-do-representante" class="form-control rounded-0 input_menor cpf" placeholder="Digite o CPF do(a) representante da empresa" value="{{ $representante->cpf_representante }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="rg-do-representante">RG do(a) representante:</label>
                    <input type="text" name="rg_representante" id="rg-do-representante" class="form-control rounded-0 input_menor rg" placeholder="Digite o RG do(a) representante da empresa" value="{{ $representante->rg_representante }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="org-ex-do-representante">Orgão Expedidor do(a) Representante:</label>
                    <input type="text" name="org_ex_representante" id="org-ex-do-representante" class="form-control rounded-0 input_menor" placeholder="Digite Orgão expedidor" value="{{ $representante->org_ex_representante }}">
                </div>
    
                <div class="m-3">
                    <label class="form-label" for="empresa-cep">CEP:</label>
                    <input type="text" name="cep" id="empresa-cep" class="form-control rounded-0 input_menor" placeholder="Digite o CEP" value="{{ $endereco->cep }}">
                </div>
    
                <div class="m-3 item1">
                    <label class="form-label" for="empresa-rua">Logradouro</label>
                    <input type="text" name="logradouro" id="empresa-rua" class="form-control rounded-0 input_longo" placeholder="Avenida, Rua, Travessa, etc..." value="{{ $endereco->logradouro }}">
                </div>
    
                <div class="m-3">
                    <label class="form-label" for="empresa-numero">Número do endereço:</label>
                    <input type="text" name="numero" id="empresa-numero" class="form-control rounded-0 input_menor" placeholder="Digite o número do endereço" value="{{ $endereco->numero }}">
                </div>
    
                <div class="m-3">
                    <label class="form-label" for="empresa-bairro">Bairro:</label>
                    <input type="text" name="bairro" id="empresa-bairro" class="form-control rounded-0 input_menor" placeholder="Digite o nome do bairro" value="{{ $endereco->bairro }}">
                </div>
    
                <div class="m-3">
                    <label class="form-label" for="empresa-cidade">Cidade:</label>
                    <input type="text" name="cidade" id="empresa-cidade" class="form-control rounded-0 input_menor" placeholder="Digite o nome da cidade" value="{{ $endereco->cidade }}">
                </div>
    
                <div class="m-3">
                    <label class="form-label" for="empresa-uf">UF (Estado):</label>
                    <select name="uf" id="empresa-uf" class="form-select  rounded-0 input_menor">
                        <option value="{{ $endereco->uf }}">{{ $endereco->uf }}</option>
                        <option value="PE">PE</option>
                        <option value="BA">BA</option>
                    </select>
                </div>
    
            </div>
    
            <button type="submit" class="btn btn-success mt-3 float-end botoes">Atualizar</button>
    
        </div>
    </form>
</div>
@endsection

@push('scripts')
@endpush
