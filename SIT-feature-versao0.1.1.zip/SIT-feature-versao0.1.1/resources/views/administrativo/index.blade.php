@extends('layouts.main')

@push('styles')

@endpush

@php
    $page = 'dashboard';
@endphp

@section('header')
    @include('administrativo.build.navbar')
@endsection

@section('sidebar')
    @include('administrativo.build.sidebar')
@endsection

@section('content')

<section id="section-user">
<div class="container">

    <div class="d-flex">
        <h4 class="page-title">Administrativo</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="{{ route('administrativo.index') }}">
                    <i class="fas fa-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="fas fa-chevron-right"></i>
            </li>
            <li class="nav-item">
                <a href="#">Dashboard</a>
            </li>
        </ul>
    </div>

    <div class="row">
        <div class="col-sm-6 col-md-3">
            <div class="card card-stats card-success cartoes card-round">
                <div class="card-body">
                    <div class="row">
                        <div class="col-4">
                            <div class="icon-big text-center">
                                <i class="fas fa-user-friends"></i>
                            </div>
                        </div>
                        <div class="col-8 col-stats">
                            <div class="numbers texto-cartao">
                                <h4 class="card-title">{{ $numero_estagio }}</h4>
                                <p class="card-category">Estagios Cadastrados</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-3">
            <div class="card card-stats card-success cartoes card-round">
                <div class="card-body ">
                    <div class="row">
                        <div class="col-4">
                            <div class="icon-big text-center">
                                <i class="fas fa-graduation-cap"></i>
                            </div>
                        </div>
                        <div class="col-8 col-stats">
                            <div class="numbers texto-cartao">
                                <h4 class="card-title">{{ $numero_curso }}</h4>
                                <p class="card-category">Cursos Cadastrados</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-3">
            <div class="card card-stats card-success cartoes card-round">
                <div class="card-body ">
                    <div class="row">
                        <div class="col-4">
                            <div class="icon-big text-center">
                                <i class="fas fa-hotel"></i>
                            </div>
                        </div>
                        <div class="col-8 col-stats">
                            <div class="numbers texto-cartao">
                                <h4 class="card-title">{{ $numero_empresa }}</h4>
                                <p class="card-category">Empresas Cadastradas</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-3">
            <div class="card card-stats card-success cartoes card-round">
                <div class="card-body ">
                    <div class="row">
                        <div class="col-4">
                            <div class="icon-big text-center">
                                <i class="fas fa-user-tie"></i>
                            </div>
                        </div>
                        <div class="col-8 col-stats">
                            <div class="numbers texto-cartao">
                                <h4 class="card-title">{{ $numero_orientador }}</h4>
                                <p class="card-category">Professores Cadastrados</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card cartao">
            <div class="card-header">
                <div class="d-flex align-items-center">
                    <div class="row w-100 align-items-center justify-content-between">
                        <h4 class="card-title col-md-5">Lista de Usuários</h4>
                        {{-- <a href="{{ route('administrativo.curso.create') }}" class="btn btn-success botoes col-md-2">Cadastrar</a>         --}}
                    </div>
                </div>
            </div>
            <div class="card-body">
    
                <div id="modal" class="modal fade" id="addRowModal" tabindex="-1" role="dialog"
                    aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header no-bd">
                                <h5 class="modal-title">
                                    <span class="fw-mediumbold">
                                        Deletar Usuario</span>
                                </h5>
                                <button type="button" class="close" data-bs-dismiss="modal"><span
                                        aria-hidden="true">&times;</span></button>
                            </div>
    
    
                            <div class="modal-body">
                                <p class="small">Você deseja DELETAR este Usuario?</p>
                                <form action="{{ route('administrativo.curso.destroy') }}" method="post">
                                    @csrf
                                    <div id="content">
                                    </div>
                                    <div class="modal-footer no-bd">
                                        <button type="button" class="btn btn-primary"
                                            data-bs-dismiss="modal">Cancelar</button>
    
                                        <button class="btn btn-danger" type="submit"
                                            data-dismiss="modal">Deletar</button>
                                    </div>
                                </form>
                            </div>
    
                        </div>
                    </div>
                </div>
    
                <div class="table-resposive">
                    <table id="add-row" class="display table table-striped table-hover">
                        <thead class="text-center">
                            <th>Nome</th>
                            <th>E-mail</th>
                            <th>Ativo</th>
                            {{-- <th>Ações</th>  --}}
                        </thead>
                
                        <tbody>
                            @foreach ($users as $user)
                                <tr class="text-center">
                                    <td>{{ $user->nome }}</td>
                                    <td>{{ $user->email }}</td>
                                    <td>{{ $user->ativo }}</td>
                                    {{-- <td>
                                        <a href="{{ route('administrativo.curso.show', $user->id) }}" data-toggle="tooltip" title="Visializar"
                                            class="btn btn-link btn-lg"
                                            data-original-title="Edit Task">
                                            <i class="fas fa-eye"></i>
                                        </a>
    
                                        <a href="{{ route('administrativo.curso.edit', $user->id) }}"
                                            data-toggle="tooltip" title="Editar"
                                            class="btn btn-link btn-lg"
                                            data-original-title="Edit Task">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                        <button onclick="deleteModal({{ $user->id }})"
                                            class="btn btn-link" data-toggle="modal"
                                            title="Deletar" data-target="#addRowModal">
                                            <i class="fa fa-times"></i>
                                        </button>
                                    </td> --}}
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>

@endsection

@push('scripts')
<script src="{{ asset('assets/administrativo/js/plugin/datatables/datatables.min.js') }}"></script>
<script src="{{ asset('assets/administrativo/js/modal.js') }}"></script>
<script>
    $(document).ready(function() {
        $('#add-row').DataTable({
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.4/i18n/pt-BR.json',
            },
        });
    });

    var action =
        '<td> <div class="form-button-action"> <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-primary btn-lg" data-original-title="Edit Task"> <i class="fa fa-edit"></i> </button> <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-danger" data-original-title="Remove"> <i class="fa fa-times"></i> </button> </div> </td>';

    $('#addRowButton').click(function() {
        $('#add-row').dataTable().fnAddData([
            $("#addName").val(),
            $("#addPosition").val(),
            $("#addOffice").val(),
            action
        ]);
        $('#addRowModal').modal('hide');

    });
</script>
@endpush