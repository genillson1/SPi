@extends('layouts.main')

@push('styles')
@endpush

@php
    $page = 'professor';
@endphp

@section('header')
    @include('administrativo.build.navbar')
@endsection

@section('sidebar')
    @include('administrativo.build.sidebar')
@endsection

@section('content')
<div class="container">
    <div class="d-flex">
        <h4 class="page-title">Administrativo</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="{{ route('administrativo.index') }}">
                    <i class="fas fa-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="fas fa-chevron-right"></i>
            </li>
            <li class="nav-item">
                <a href="{{ route('administrativo.orientador.index') }}">Professores</a>
            </li>
            <li class="separator">
                <i class="fas fa-chevron-right"></i>
            </li>
            <li class="nav-item">
                <a href="#">Editar</a>
            </li>
        </ul>
    </div>
    <form action="{{ route('administrativo.orientador.update', $orientador->id) }}" method="post">
        @method('PUT')
        @csrf
        @if ($errors->first('error'))
            <div class=" alert alert-warning" role="alert">
                {{ $errors->first('error') }}
                Preencha todos os campos
            </div>
        @endif

        @if (session('session'))
            <div class="alert alert-success" role="alert">
                {{ session('session') }}
            </div>
        @endif

        <div>

            <h4>Cadastro de Professores</h4>

            <div class="container_inputs">

                <div class="m-3">
                    <label class="form-label" for="nome">Nome do professor:</label>
                    <input type="text" name="nome" id="nome" class="form-control rounded-0 input_longo" placeholder="Digite o nome professor" value="{{ $orientador->nome }}">
                </div>

                <div class="m-3">
                    <label class="form-label" for="email">E-Mail do Professor:</label>
                    <input type="email" name="email" id="email" class="form-control rounded-0 input_longo" placeholder="Digite o e-mail do professor" value="{{ $orientador->email }}">
                </div>

            </div>

            <button type="submit" class="btn btn-success mt-3 float-end botoes">Atualizar</button>

        </div>
    </form>
</div>
@endsection

@push('scripts')
    
@endpush