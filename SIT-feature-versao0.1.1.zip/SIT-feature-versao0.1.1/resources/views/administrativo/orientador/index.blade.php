@extends('layouts.main')

@push('styles')
@endpush

@php
    $page = 'professores';
@endphp

@section('header')
    @include('administrativo.build.navbar')
@endsection

@section('sidebar')
    @include('administrativo.build.sidebar')
@endsection

@section('content')
<div class="container">
    <div class="d-flex">
        <h4 class="page-title">Administrativo</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="{{ route('administrativo.index') }}">
                    <i class="fas fa-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="fas fa-chevron-right"></i>
            </li>
            <li class="nav-item">
                <a href="#">Professores</a>
            </li>
        </ul>
    </div>
    @if ($errors->first('error'))
        <div class=" alert alert-warning" role="alert">
            {{ $errors->first('error') }}
            Preencha todos os campos
        </div>
    @endif

    @if (session('session'))
        <div class="alert alert-success" role="alert">
            {{ session('session') }}
        </div>
    @endif
    <div class="card cartao">
        <div class="card-header">
            <div class="d-flex align-items-center">
                <div class="row w-100 align-items-center justify-content-between">
                    <h4 class="card-title col-md-5">Lista de Orientadores</h4>
                    <a href="{{ route('administrativo.orientador.create') }}" class="btn btn-success botoes col-md-2">Cadastrar</a>
                </div>
            </div>
        </div>
        <div class="card-body">

            <div id="modal" class="modal fade" id="addRowModal" tabindex="-1" role="dialog"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header no-bd">
                            <h5 class="modal-title">
                                <span class="fw-mediumbold">
                                    Deletar Orientador</span>
                            </h5>
                            <button type="button" class="close" data-bs-dismiss="modal"><span
                                    aria-hidden="true">&times;</span></button>
                        </div>


                        <div class="modal-body">
                            <p class="small">Você deseja DELETAR este Orientador?</p>
                            <form action="{{ route('administrativo.orientador.destroy') }}" method="post">
                                @csrf
                                <div id="content">
                                </div>
                                <div class="modal-footer no-bd">
                                    <button type="button" class="btn btn-primary"
                                        data-bs-dismiss="modal">Cancelar</button>

                                    <button class="btn btn-danger" type="submit"
                                        data-dismiss="modal">Deletar</button>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>

            <div class="table-resposive">
                <table id="add-row" class="display table table-striped table-hover">
                    <thead class="text-center">
                        <th>Nome</th>
                        <th>E-mail</th>
                        <th>Ações</th>
                    </thead>
            
                    <tbody>
                        @foreach ($orientadores as $orientador)
                            <tr class="text-center">
                                <td>{{ $orientador->nome }}</td>
                                <td>{{ $orientador->email }}</td>
                                <td>
                                    <a href="{{ route('administrativo.orientador.show', $orientador->id) }}" data-toggle="tooltip" title="Visializar"
                                        class="btn btn-link btn-lg"
                                        data-original-title="Edit Task">
                                        <i class="fas fa-eye"></i>
                                    </a>

                                    <a href="{{ route('administrativo.orientador.edit', $orientador->id) }}"
                                        data-toggle="tooltip" title="Editar"
                                        class="btn btn-link btn-lg"
                                        data-original-title="Edit Task">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <button onclick="deleteModal({{ $orientador->id }})"
                                        class="btn btn-link" data-toggle="modal"
                                        title="Deletar" data-target="#addRowModal">
                                        <i class="fa fa-times"></i>
                                    </button>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="{{ asset('assets/administrativo/js/plugin/datatables/datatables.min.js') }}"></script>
<script src="{{ asset('assets/administrativo/js/modal.js') }}"></script>
<script>
    $(document).ready(function() {
        $('#add-row').DataTable({
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.4/i18n/pt-BR.json',
            },
        });
    });

    var action =
        '<td> <div class="form-button-action"> <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-primary btn-lg" data-original-title="Edit Task"> <i class="fa fa-edit"></i> </button> <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-danger" data-original-title="Remove"> <i class="fa fa-times"></i> </button> </div> </td>';

    $('#addRowButton').click(function() {
        $('#add-row').dataTable().fnAddData([
            $("#addName").val(),
            $("#addPosition").val(),
            $("#addOffice").val(),
            action
        ]);
        $('#addRowModal').modal('hide');

    });
</script>
@endpush