@extends('layouts.main')

@push('styles')
@endpush

@section('header')
    @include('gestao.build.navbar')
@endsection

@section('sidebar')
    @include('gestao.build.sidebar')
@endsection

@section('content')
    <table>
        <thead>
            <th>Nome</th>
            <th>CNPJ</th>
            <th>Representante</th>
            <th>Instituicao</th>
        </thead>

        <tbody>
            @foreach ($campus as $campi)
                <tr>
                    <td>{{ $campi->nome }}</td>
                    <td>{{ $campi->cnpj }}</td>
                    <td>{{ $campi->nome_rep }}</td>
                    <td>{{ $campi->instituicao_id }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection

@push('scripts')
    
@endpush