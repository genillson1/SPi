@extends('layouts.main')

@push('styles')
@endpush

@section('header')
    @include('gestao.build.navbar')
@endsection

@section('sidebar')
    @include('gestao.build.sidebar')
@endsection

@section('content')
    <form>
        <h3>Campus</h3><br>
        <label for="">Nome: </label>
        <input type="text" value="{{ $campus->nome }}" disabled>
        <label for="">CNPJ: </label>
        <input type="text" value="{{ $campus->cnpj }}" disabled>
        <label for="">Instituição: </label>
        <input type="text" value="{{ $instituicao->nome }}" disabled><br>
        <h3>Representante campus</h3>
        <label for="">Nome: </label>
        <input type="text" value="{{ $campus->nome_rep }}" disabled>
        <label for="">Cargo: </label>
        <input type="text" value="{{ $campus->cargo_rep }}" disabled>
        <label for="">CPF: </label>
        <input type="text" value="{{ $campus->cpf_rep }}" disabled>
        <label for="">RG: </label>
        <input type="text" value="{{ $campus->rg_rep }}" disabled>
        <label for="">Orgão Expedidor</label>
        <input type="text" value="{{ $campus->org_ex_rep }}" disabled><br>
        <h3>Endereco Campus</h3>
        <label for="">Logradouro: </label>
        <input type="text" value="{{ $endereco->logradouro }}" disabled>
        <label for="">Numero: </label>
        <input type="text" value="{{ $endereco->numero }}" disabled>
        <label for="">Bairro: </label>
        <input type="text" value="{{ $endereco->bairro }}" disabled>
        <label for="">CEP: </label>
        <input type="text" value="{{ $endereco->cep }}" disabled>
        <label for="">Cidade: </label>
        <input type="text" value="{{ $endereco->cidade }}" disabled>
        <label for="">UF: </label>
        <input type="text" value="{{ $endereco->uf }}" disabled>
    </form>
@endsection

@push('scripts')
    
@endpush