@extends('layouts.main')

@push('styles')
@endpush

@section('header')
    @include('gestao.build.navbar')
@endsection

@section('sidebar')
    @include('gestao.build.sidebar')
@endsection

@section('content')
    <form action="{{ route('gestao.campus.store') }}" method="post">
        @csrf
        {{-- Dados do campus --}}
        <input type="text" name="nome">
        <input type="text" name="cnpj">
        <select name="instituicao_id">
            <option value="0" selected>Selecione a instituição</option>
            @foreach ($instituicoes as $instituicao)
                <option value="{{ $instituicao->id }}">{{ $instituicao->nome }}</option>
            @endforeach
        </select><br>
        {{-- Dados do representante do campus --}}
        <input type="text" name="nome_rep">
        <input type="text" name="cargo_rep">
        <input type="text" name="cpf_rep">
        <input type="text" name="rg_rep">
        <input type="text" name="org_ex_rep"><br>
        {{-- Endereço do campus --}}
        <input type="text" name="logradouro">
        <input type="text" name="numero">
        <input type="text" name="bairro">
        <input type="text" name="cep">
        <input type="text" name="cidade">
        <input type="text" name="uf"><br>

        <input type="submit" value="Enviar">
         @if (session('session'))
             <h1>{{ session('session') }}</h1>
         @endif

         @if ($errors->first('error'))
             <h1>{{ $errors->first('error') }}</h1>
         @endif
    </form>
@endsection

@push('scripts')
    
@endpush