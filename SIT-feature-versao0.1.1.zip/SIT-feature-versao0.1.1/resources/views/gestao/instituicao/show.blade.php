@extends('layouts.main')

@push('styles')
@endpush

@section('header')
    @include('gestao.build.navbar')
@endsection

@section('sidebar')
    @include('gestao.build.sidebar')
@endsection

@section('content')
    <form>
        <label for="">Nome: </label>
        <input type="text" value="{{ $instituicao->nome }}" disabled>
    </form>
@endsection

@push('scripts')
    
@endpush