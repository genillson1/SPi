@extends('layouts.main')

@push('styles')
@endpush

@section('header')
    @include('gestao.build.navbar')
@endsection

@section('sidebar')
    @include('gestao.build.sidebar')
@endsection

@section('content')
    <table>
        <thead>
            <th>Nome</th>
            <th>Ações</th>
        </thead>
        <tbody>
            @foreach ($instituicoes as $instituicao)
                <tr>
                    <td>{{ $instituicao->nome }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection

@push('scripts')
    
@endpush