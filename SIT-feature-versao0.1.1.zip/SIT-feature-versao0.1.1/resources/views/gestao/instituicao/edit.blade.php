@extends('layouts.main')

@push('styles')
@endpush

@section('header')
    @include('gestao.build.navbar')
@endsection

@section('sidebar')
    @include('gestao.build.sidebar')
@endsection

@section('content')
    <form action="{{ route('gestao.instituicao.update', $instituicao->id) }}" method="post">
        @csrf
        @method('PUT')
        <input type="text" name="nome" value="{{ $instituicao->nome }}">
        <input type="submit" value="Enviar">
    </form>

    @if (session('session'))
        <h1>{{ session('session') }}</h1>
    @endif

    @if ($errors->first('error'))
        <h1>Preencha todos os campos</h1>
    @endif
@endsection

@push('scripts')

@endpush
