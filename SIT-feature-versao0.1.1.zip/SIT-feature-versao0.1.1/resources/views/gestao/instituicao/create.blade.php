@extends('layouts.main')

@push('styles')
@endpush

@section('header')
    @include('gestao.build.navbar')
@endsection

@section('sidebar')
    @include('gestao.build.sidebar')
@endsection

@section('content')
    <form action="{{ route('gestao.instituicao.store') }}" method="post">
        @csrf
        <input type="text" name="nome">
        <input type="submit" value="Enviar">
    </form>

    @if (session('session'))
        <h1>{{ session('session') }}</h1>
    @endif

    @if ($errors->first('error'))
        <h1>Preencha todos os campos</h1>
    @endif
@endsection

@push('scripts')
    
@endpush