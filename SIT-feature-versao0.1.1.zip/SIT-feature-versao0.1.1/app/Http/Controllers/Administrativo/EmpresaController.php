<?php

namespace App\Http\Controllers\Administrativo;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\{
    Empresa,
    Endereco,
    Representante,
};

class EmpresaController extends Controller
{
    //Pagina inicial do crud
    public function index(){
        $empresas = Empresa::get();

        return view('administrativo.empresa.index', ["empresas" => $empresas]);
    }

    //Pagina com formulario
    public function create(){
        return view('administrativo.empresa.create');
    }

    //gravação dos dados no banco
    public function store(Request $request){
        $data_empresa = $request->only([
            'nome', 'cnpj', 'natureza_juridica'
        ]);

        $data_endereco = $request->only([
            'logradouro', 'numero', 'bairro', 'cep', 'cidade', 'uf'
        ]);

        $data_representante = $request->only([
            'nome_representante', 'cargo_representante', 'cpf_representante', 'rg_representante', 'org_ex_representante'
        ]);

        try {
            $endereco = Endereco::create($data_endereco);
            try {
                $data_empresa['endereco_id'] = $endereco->id;
                $empresa = Empresa::create($data_empresa);
                try {
                    $data_representante['empresa_id'] = $empresa->id;
                    $representante = Representante::create($data_representante);
                    return back()->with(['session' => 'Cadastro de Empresa Realizado']);
                } catch (\Exception $exception) {
                    return back()->withErrors(['errorRepresentante' => 'Representante invalido']);                    
                }
            } catch (\Exception $exception) {
                return back()->withErrors(['errorEmpresa' => 'Empresa invalida']);
            }
        } catch (\Exception $exception) {
            return back()->withErrors(['errorEndereco' => 'Endereço invalido']);
        }
    }

    //Pagina com formulario para edição
    public function edit($id){
        $empresa = Empresa::find($id);
        $endereco = Endereco::find($empresa->endereco_id);
        $representante = Representante::where('empresa_id', $empresa->id)->first();

        return view('administrativo.empresa.edit', ["empresa" => $empresa, "endereco" => $endereco, "representante" => $representante]);
    } 

    //Gravação das alterações no banco
    public function update(Request $request, $id){
        $empresa = Empresa::find($id);
        $endereco = Endereco::find($empresa->endereco_id);
        $representante = Representante::where('empresa_id', $empresa->id)->first();

        $data_empresa = $request->only([
            'nome', 'cnpj', 'natureza_juridica'
        ]);

        $data_endereco = $request->only([
            'logradouro', 'numero', 'bairro', 'cep', 'cidade', 'uf'
        ]);

        $data_representante = $request->only([
            'nome_representante', 'cargo_representante', 'cpf_representante', 'rg_representante', 'org_ex_representante'
        ]);

        try {
            $endereco->update($data_endereco);
            try {
                $empresa->update($data_empresa);
                try {
                    $representante->update($data_representante);
                    return back()->with(['session' => 'Atualização de Empresa Realizado']);
                } catch (\Exception $exception) {
                    return back()->withErrors(['errorRepresentante' => 'Representante invalido']);                    
                }
            } catch (\Exception $exception) {
                return back()->withErrors(['errorEmpresa' => 'Empresa invalida']);
            }
        } catch (\Exception $exception) {
            return back()->withErrors(['errorEndereco' => 'Endereço invalido']);
        }
    }

    //Visualização de registro especifico
    public function show($id){
        $empresa = Empresa::find($id);
        $endereco = Endereco::find($empresa->endereco_id);
        $representante = Representante::where('empresa_id', $empresa->id)->first();

        return view('administrativo.empresa.show', ["empresa" => $empresa, "endereco" => $endereco, "representante" => $representante]);
    }

    //Apagar registro do banco
    public function destroy(Request $request){
        $empresa = Empresa::find($request->id);

        try {
            $empresa->delete();
            return redirect()->route('administrativo.empresa.index')->with("session", "Empresa deletada com sucesso");
        } catch (\Exception $exception) {
            return redirect()->route('administrativo.empresa.index')->withErrors(["error" => "Não foi possivel deletar a empresa"]);
        }
    }
}
