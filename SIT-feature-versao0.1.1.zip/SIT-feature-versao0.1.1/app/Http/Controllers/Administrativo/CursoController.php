<?php

namespace App\Http\Controllers\Administrativo;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Curso;

class CursoController extends Controller
{
    //Pagina inicial do crud
    public function index(){
        $cursos = Curso::get();

        return view('administrativo.curso.index', ["cursos" => $cursos]);
    }

    //Pagina com formulario
    public function create(){
        return view('administrativo.curso.create');
    }

    //gravação dos dados no banco
    public function store(Request $request){
        $data = $request->all();
        
        try {
            $curso = Curso::create($data);
            return back()->with("session", "Cadastro de Curso realizado");
        } catch (\Exception $exception) {
            return back()->withErrors(["error" => "Preencha todos os campos"]);
        }
    }

    //Pagina com formulario para edição
    public function edit($id){
        $curso = Curso::find($id);

        return view('administrativo.curso.edit', ["curso" => $curso]);
    }

    //Gravação das alterações no banco
    public function update(Request $request, $id){
        $data = $request->all();
        $curso = Curso::find($id);
        
        try {
            $curso->update($data);
            return back()->with("session", "Atualização de Curso realizado");
        } catch (\Exception $exception) {
            return back()->withErrors(["error" => "Preencha todos os campos"]);
        }
    }

    //Visualização de registro especifico
    public function show($id){
        $curso = Curso::find($id);
        
        return view('administrativo.curso.show', ["curso" => $curso]);
    }

    //Apagar registro do banco
    public function destroy(Request $request){
        $curso = Curso::find($request->id);

        try {
            $curso->delete();
            return redirect()->route('administrativo.curso.index')->with("session", "Curso deletado com sucesso");
        } catch (\Exception $exception) {
            return redirect()->route('administrativo.curso.index')->withErrors(["error" => "Não foi possivel deletar o Curso"]);
        }
    }
}
