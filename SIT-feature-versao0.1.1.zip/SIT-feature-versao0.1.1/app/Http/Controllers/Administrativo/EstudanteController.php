<?php

namespace App\Http\Controllers\Administrativo;

use App\Models\{
    Aluno,
    Endereco,
    Curso,
    Empresa,
    Orientador,
    Representante,
    Estagio,
    User,
};
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
class EstudanteController extends Controller
{
    //Pagina inicial do crud
    public function index(){
        $numero_empresa = Empresa::get()->count();
        $numero_orientador = Orientador::get()->count();
        $numero_curso = Curso::get()->count();
        $numero_estagio = Estagio::get()->count();

        $estagios = DB::table('alunos')
            ->join('estagios', 'alunos.id', '=', 'estagios.aluno_id')
            ->join('empresas', 'estagios.empresa_id', '=', 'empresas.id')
            ->join('cursos', 'estagios.curso_id', '=', 'cursos.id')
            ->join('orientadors', 'estagios.orientador_id', '=', 'orientadors.id')
            ->select('estagios.id', 'estagios.status','alunos.nome as nome_aluno', 'cursos.nome as nome_curso', 'empresas.nome as nome_empresa', 'orientadors.nome as nome_orientador')
            ->get();
            // dd($aluno);
            // $estagios = Estagio::get();

        return view('administrativo.estudante.index', [
            "estagios" => $estagios, "numero_empresa" => $numero_empresa, "numero_orientador" => $numero_orientador, 
            "numero_curso" => $numero_curso, "numero_estagio" => $numero_estagio
        ]);
    }

    //Pagina com formulario
    public function create(){
        $cursos = Curso::all();
        $empresas = Empresa::all();
        $orientadores = Orientador::all();

        return view('administrativo.estudante.create', [
            'cursos' => $cursos, 'empresas' => $empresas, 'orientadores' => $orientadores
        ]); 
    }

    //gravação dos dados no banco
    public function store(Request $request){
        $data_endereco = $request->only([
            'logradouro', 'numero', 'bairro', 'cep', 'cidade', 'uf'
        ]);

        
        $data_aluno = $request->only([
            'nome', 'cpf', 'rg', 'org_ex', 'data_nascimento', 'email', 'telefone', 'usuario_id', 'endereco_id'
        ]);
        $data_aluno['usuario_id'] = 0;
        $dados = $this->FormatCpf($request->cpf, $request->rg, $request->telefone);
        $data_aluno['cpf'] = $dados['cpf'];
        $data_aluno['rg'] = $dados['rg'];
        $data_aluno['telefone'] = $dados['telefone'];

        $data_estagio = $request->only([
            'periodo_curso', 'data_inicio', 'data_termino', 'duracao', 'aluno_id', 'curso_id', 
            'orientador_id', 'empresa_id', 'nome_supervisor', 'cargo_supervisor', 'email_supervisor',
            'telefone_supervisor'
        ]);
        try {
            $data_estagio['data_termino'] = $request->data_inicio;
            $endereco = Endereco::create($data_endereco);
            $data_aluno['endereco_id'] = $endereco->id;
            $aluno = Aluno::create($data_aluno);
            $data_estagio['aluno_id'] = $aluno->id;
            $estagio = Estagio::create($data_estagio);
            return back()->with("session", "Cadastro de Estagio Realizado");
        } catch (\Exception $e) {
            return back()->withErrors(["error" => "Preencha todos os campos"]);
        }
    }

    //Pagina com formulario para edição
    public function edit($id){
        $estagio = Estagio::where('id', $id)->get()->first();
        $aluno = Aluno::get()->where('id', $estagio->aluno_id)->first();
        $endereco = Endereco::get()->where('id', $aluno->endereco_id)->first();
        $curso = Curso::find($estagio->curso_id);
        $empresa = Empresa::find($estagio->empresa_id);
        $representante = Representante::where('empresa_id', $empresa->id)->first();
        $orientador = Orientador::find($estagio->orientador_id);

        $cursos = Curso::all();
        $empresas = Empresa::all();
        $orientadores = Orientador::all();

        return view('administrativo.estudante.edit', [
            "estagio" => $estagio, "aluno" => $aluno, "endereco" => $endereco, "curso" => $curso, "empresa" => $empresa,
            "orientador" => $orientador, "representante" => $representante,
            'cursos' => $cursos, 'empresas' => $empresas, 'orientadores' => $orientadores
        ]);
    }

    //Gravação das alterações no banco
    public function update(Request $request, $id){
        $estagio = Estagio::find($id);
        $aluno = Aluno::get()->where('id', $estagio->aluno_id)->first();
        $endereco = Endereco::find($aluno->endereco_id);

        $data_endereco = $request->only([
            'logradouro', 'numero', 'bairro', 'cep', 'cidade', 'uf'
        ]);

        
        $data_aluno = $request->only([
            'nome', 'cpf', 'rg', 'org_ex', 'data_nascimento', 'email', 'telefone', 'usuario_id', 'endereco_id'
        ]);
        if($aluno->usuario_id != 0){
            $data_aluno['usuario_id'] = $aluno->usuario_id;
        }else{
            $data_aluno['usuario_id'] = 0;
        }
        $dados = $this->FormatCpf($request->cpf, $request->rg, $request->telefone);
        $data_aluno['cpf'] = $dados['cpf'];
        $data_aluno['rg'] = $dados['rg'];
        $data_aluno['telefone'] = $dados['telefone'];

        $data_estagio = $request->only([
            'periodo_curso', 'data_inicio', 'data_termino', 'duracao', 'aluno_id', 'curso_id', 
            'orientador_id', 'empresa_id', 'nome_supervisor', 'cargo_supervisor', 'email_supervisor',
            'telefone_supervisor'
        ]);

        $data_estagio['data_termino'] = $request->data_inicio;
        $data_aluno['endereco_id'] = $endereco->id;
        $data_estagio['aluno_id'] = $aluno->id;
        try {
            return back()->with('session', 'Atualização de Estagio Realizado');
        } catch (\Throwable $th) {
            return back()->withErrors(["error" => "Preencha todos os campos"]);
        }
        $estagio->update($data_estagio);
        $aluno->update($data_aluno);
        $endereco->update($data_endereco);
    }

    //Visualização de registro especifico
    public function show($id){
        $estagio = Estagio::where('id', $id)->get()->first();
        $aluno = Aluno::get()->where('id', $estagio->aluno_id)->first();
        $endereco = Endereco::get()->where('id', $aluno->endereco_id)->first();
        $curso = Curso::find($estagio->curso_id);
        $empresa = Empresa::find($estagio->empresa_id);
        $representante = Representante::where('empresa_id', $empresa->id)->first();
        $orientador = Orientador::find($estagio->orientador_id);

        $cursos = Curso::all();
        $empresas = Empresa::all();
        $orientadores = Orientador::all();

        return view('administrativo.estudante.show', [
            "estagio" => $estagio, "aluno" => $aluno, "endereco" => $endereco, "curso" => $curso, "empresa" => $empresa,
            "orientador" => $orientador, "representante" => $representante,
            'cursos' => $cursos, 'empresas' => $empresas, 'orientadores' => $orientadores
        ]);
    }

    //Apagar registro do banco
    public function destroy(Request $request){
        $estagio = Estagio::find($request->id);
        try {
            $estagio->delete();

            return back()->with('session', 'Estagio deletado');
        } catch (\Throwable $th) {
            return back()->withErrors(["error" => "Não foi possivel deletar o Estagio"]);
        }
    }

    public function FormatCpf($requestCpf, $requestRg, $requestTelefone){
        // Extrai somente os números
        $cpf = preg_replace( '/[^0-9]/is', '', $requestCpf );
        $rg = preg_replace( '/[^0-9]/is', '', $requestRg );
        $telefone = preg_replace( '/[^0-9]/is', '', $requestTelefone );
        $dados = ['cpf' => $cpf, 'rg' => $rg, 'telefone' => $telefone];
        return $dados;
    }
}
