<?php

namespace App\Http\Controllers\Administrativo;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Orientador;

class OrientadorController extends Controller
{
    //Pagina inicial do crud
    public function index(){
        $orientadores = Orientador::get();

        return view('administrativo.orientador.index', ["orientadores" => $orientadores]);
    }

    //Pagina com formulario
    public function create(){
        return view('administrativo.orientador.create');
    }

    //gravação dos dados no banco
    public function store(Request $request){
        $data = $request->all();

        try {
            $orientador = Orientador::create($data);
            return back()->with(['session' => 'Cadastrao de Orientador Realizado']);
        } catch (\Exception $exception) {
            return back()->withErrors(['error' => 'Preencha todos os campos']);
        }
    }

    //Pagina com formulario para edição
    public function edit($id){
        $orientador = Orientador::find($id);

        return view('administrativo.orientador.edit', ['orientador' => $orientador]);
    }

    //Gravação das alterações no banco
    public function update(Request $request, $id){
        $orientador = Orientador::find($id);
        $data = $request->all();

        try {
            $orientador->update($data);
            return back()->with(['session' => 'Atualização de Orientador Realizado']);
        } catch (\Exception $exception) {
            return back()->withErrors(['error' => 'Preencha todos os campos']);
        }
    }

    //Visualização de registro especifico
    public function show($id){
        $orientador = Orientador::find($id);

        return view('administrativo.orientador.show', ['orientador' => $orientador]);
    }

    //Apagar registro do banco
    public function destroy(Request $request){
        $orientador = Orientador::find($request->id);

        try {
            $orientador->delete();
            return redirect()->route('administrativo.orientador.index')->with("session", "Orientador deletado com sucesso");
        } catch (\Exception $exception) {
            return redirect()->route('administrativo.orientador.index')->withErrors(["error" => "Não foi possivel deletar o Curso"]);
        }
    }
}
