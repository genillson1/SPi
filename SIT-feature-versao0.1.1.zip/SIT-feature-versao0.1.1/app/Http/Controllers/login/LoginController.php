<?php

namespace App\Http\Controllers\login;

use App\Mail\Verification;
use Illuminate\Support\Facades\Mail;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Admin;
use Carbon\Carbon;

class LoginController extends Controller
{
    public function index(){
        return view('login.index');
    }

    public function login(Request $request){
        $credenciais = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);

        if (Auth::guard('admin')->attempt($credenciais)) {
            return redirect()->route('administrativo.index');
        }else if (Auth::guard('web')->attempt($credenciais)) {
            if(Auth::user()->ativo == 1){
                return redirect()->route('estagiario.index');
            }else{
                return back()->withErrors(["error" => 'E-mail de usuario não Verificado']);
            }
        }else{
            return back()->withErrors(["error" => 'E-Mail ou senha incorretos']);
        }
    }

    public function create(){
        return view('login.register');
    }

    public function store(Request $request){

        $usuario = User::whereEmail($request->email)->first();

        if($usuario)
            return back()->withErrors(["error" => 'Email já cadastrado']);

        if($request->password !== $request->confirm_password)
            return back()->withErrors(["error" => 'Senha e confirmar senha não combinão']);

        $usuario = new User();
        $usuario->nome = $request->nome;
        $usuario->email = $request->email;
        $email_institucional   = '@aluno.ifsertao-pe.edu.br';
        $verificacao = strpos( $usuario->email, $email_institucional );
        if($verificacao == false){
            return back()->withErrors(["error" => 'Use o email institucional']);
        }else{
            $usuario->password = Hash::make($request->password);
            $usuario->save();
        }
        
        try {
            Mail::to($usuario->email)->send(new Verification($usuario));
            return redirect()->route('login.index')->with("session", "Cadastro realizado, para acessar verifique seu e-mail");
        } catch (\Exception $exception) {
            return back()->withErrors(["error" => 'Não foi possivel realizar o cadastro']);
        }
    }

    public function verification($id){
        $usuario = User::find($id);
        $current = Carbon::now();

        $usuario->ativo = 1;
        $usuario->email_verified_at = $current;
        $usuario->update();

        return redirect()->route('login.index')->with('session', "Usuario verificado, Agora é possivel efetuar o login $usuario->nome");
    }

    public function logout(){
        Auth::logout();

        return redirect()->route('login.index');
    }
}
