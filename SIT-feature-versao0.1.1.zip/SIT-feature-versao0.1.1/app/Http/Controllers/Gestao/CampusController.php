<?php

namespace App\Http\Controllers\Gestao;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{
    Campu,
    Endereco,
    Instituicao,
};

class CampusController extends Controller
{
    //Pagina inicial do crud
    public function index(){
        $campus = Campu::get();

        return view('gestao.campus.index', ['campus' => $campus]);
    }

    //Pagina com formulario
    public function create(){
        $instituicoes = Instituicao::get();

        return view('gestao.campus.create', ["instituicoes" => $instituicoes]);
    }

    //gravação dos dados no banco
    public function store(Request $request){
        $data_campus = $request->only([
            'nome', 'cnpj', 'nome_rep', 'cargo_rep', 'cpf_rep', 'rg_rep', 'org_ex_rep', 'instituicao_id'
        ]);

        $data_endereco = $request->only([
            'logradouro', 'numero', 'bairro', 'cep', 'cidade', 'uf'
        ]);
        
        try {
            $endereco = Endereco::create($data_endereco);
            try {
                $data_campus['endereco_id'] = $endereco->id;
                $campus = Campu::create($data_campus);

                return back()->with(['session' => 'Campus registrado']);
            } catch (\Exceptionn $exception) {
                return back()->withErrors(['error' => 'Não foi possivel adicionar o campus']);
            }
        } catch (\Exception $exception) {
            return back()->withErrors(['error' => 'Não foi possivel adicionar o endereço']);
        }
    }

    //Pagina com formulario para edição
    public function edit($id){
        $campus = Campu::find($id);
        $instituicao = Instituicao::find($campus->instituicao_id);
        $instituicoes = Instituicao::get();
        $endereco = Endereco::find($campus->endereco_id);

        return view('gestao.campus.edit', ['campus' => $campus, 'instituicao' => $instituicao, 'instituicoes' => $instituicoes,'endereco' => $endereco]);
    }

    //Gravação das alterações no banco
    public function update(Request $request, $id){
        $campus = Campu::find($id);
        $endereco = Endereco::find($campus->endereco_id);

        $data_campus = $request->only([
            'nome', 'cnpj', 'nome_rep', 'cargo_rep', 'cpf_rep', 'rg_rep', 'org_ex_rep', 'instituicao_id'
        ]);

        $data_endereco = $request->only([
            'logradouro', 'numero', 'bairro', 'cep', 'cidade', 'uf'
        ]);
        
        try {
            $endereco->update($data_endereco);
            try {
                $campus->update($data_campus);

                return back()->with(['session' => 'Campus Atualizado']);
            } catch (\Exceptionn $exception) {
                return back()->withErrors(['error' => 'Não foi possivel atualizar o campus']);
            }
        } catch (\Exception $exception) {
            return back()->withErrors(['error' => 'Não foi possivel atualizar o endereço']);
        }
    }

    //Visualização de registro especifico
    public function show($id){
        $campus = Campu::find($id);
        $instituicao = Instituicao::find($campus->instituicao_id);
        $endereco = Endereco::find($campus->endereco_id);

        return view('gestao.campus.show', ['campus' => $campus, 'instituicao' => $instituicao, 'endereco' => $endereco]);
    }

    //Apagar registro do banco
    public function destroy($id){
        return dd('Apagar registro');
    }
}
