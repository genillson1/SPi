<?php

namespace App\Http\Controllers\Gestao;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Instituicao;

class InstituicaoController extends Controller
{
    //Pagina inicial do crud
    public function index(){
        $instituicoes = Instituicao::get();

        return view('gestao.instituicao.index', ['instituicoes' => $instituicoes]);
    }

    //Pagina com formulario
    public function create(){
        return view('gestao.instituicao.create');
    }

    //gravação dos dados no banco
    public function store(Request $request){
        $data = $request->all();

        try {
            $instituicao = Instituicao::create($data);
            return back()->with(['session' => 'Dados atualizados']);
        } catch (\Exception $exception) {
            return back()->withErrors(['error' => 'Preencha todos os campos']);
        }
    }

    //Pagina com formulario para edição
    public function edit($id){
        $instituicao = Instituicao::find($id);

        return view('gestao.instituicao.edit', ['instituicao' => $instituicao]);
    }

    //Gravação das alterações no banco
    public function update(Request $request, $id){
        $instituicao = Instituicao::find($id);
        $data = $request->all();

        try {
            $instituicao->update($data);
            return back()->with(['session' => 'Dados registrados']);
        } catch (\Exception $exception) {
            return back()->withErrors(['error' => 'Preencha todos os campos']);
        }
    }

    //Visualização de registro especifico
    public function show($id){
        $instituicao = Instituicao::find($id);

        return view('gestao.instituicao.show', ['instituicao' => $instituicao]);
    }

    //Apagar registro do banco
    public function destroy($id){
        $instituicao = Instituicao::find($request->id);

        try {
            $instituicao->delete();
            return redirect()->route('gestao.instituicao.index')->with("session", "Instituição deletada com sucesso");
        } catch (\Exception $exception) {
            return redirect()->route('gestao.instituicao.index')->withErrors(["error" => "Não foi possivel deletar a Instituição"]);
        }
    }
}
