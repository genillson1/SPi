<?php

namespace App\Http\Controllers\Estagiario;

use App\Models\{
    Aluno,
    Endereco,
    Curso,
    Empresa,
    Orientador,
    Estagio,
    User,
};
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class EstagioController extends Controller
{
    //Pagina inicial do crud
    public function index(){
        return dd('Pagina inicial');
    }

    //Pagina com formulario
    public function create(){
        $cursos = Curso::all();
        $empresas = Empresa::all();
        $orientadores = Orientador::all();
        
        return view('estagiario.dados.estagio.create', [
            'cursos' => $cursos, 'empresas' => $empresas, 'orientadores' => $orientadores
        ]); 
    }
    
    //gravação dos dados no banco
    public function store(Request $request){
        $aluno = $this->getAluno();
        $data_estagio = $request->only([
            'periodo_curso', 'data_inicio', 'data_termino', 'duracao', 'aluno_id', 'curso_id', 
            'orientador_id', 'empresa_id', 'nome_supervisor', 'cargo_supervisor', 'email_supervisor',
            'telefone_supervisor', 'status'
        ]);
        $data_estagio['status'] = 1;
        $data_estagio['data_termino'] = $request->data_inicio;
        $data_estagio['aluno_id'] = $aluno;

        
        try {
            $estagio = Estagio::create($data_estagio);
            
            return back()->with('session', 'Dados gravados com sucesso');
        } catch(\Exception $exception){
            return redirect()->back()->withErrors(['error' => 'Preencha todos os campos']);
        }
    }

    //Pagina com formulario para edição
    public function edit(){
        $aluno = $this->getAluno();
        $estagio = Estagio::where('aluno_id', $aluno)->get()->first();
        $curso = Curso::find($estagio->curso_id);
        $empresa = Empresa::find($estagio->empresa_id);
        $orientador = Orientador::find($estagio->orientador_id);

        $cursos = Curso::all();
        $empresas = Empresa::all();
        $orientadores = Orientador::all();

        return view('estagiario.dados.estagio.edit' , [
            "estagio" => $estagio, "curso_aluno" => $curso, "empresa_aluno" => $empresa, "orientador_aluno" => $orientador,
            'cursos' => $cursos, 'empresas' => $empresas, 'orientadores' => $orientadores

        ]);
    }

    //Gravação das alterações no banco
    public function update(Request $request){
        // $aluno = Auth::user()->id;
        $aluno = $this->getAluno();
        $estagio = Estagio::where('aluno_id', $aluno)->get()->first();

        $data_estagio = $request->only([
            'periodo_curso', 'data_inicio', 'data_termino', 'duracao', 'aluno_id', 'curso_id', 
            'orientador_id', 'empresa_id', 'nome_supervisor', 'cargo_supervisor', 'email_supervisor',
            'telefone_supervisor'
        ]);
        $data_estagio['data_termino'] = $request->data_inicio;
        $data_estagio['aluno_id'] = $aluno;

        
        try {
            $estagio->update($data_estagio);
            
            return back()->with('session', 'Dados atualizados com sucesso');
        } catch(\Exception $exception){
            return redirect()->back()->withErrors(['error' => 'Preencha todos os campos']);
        }
    }

    //Visualização de registro especifico
    public function show(){
        $aluno = $this->getAluno();
        $estagio = Estagio::where('aluno_id', $aluno)->get()->first();
        $curso = Curso::find($estagio->curso_id);
        $empresa = Empresa::find($estagio->empresa_id);
        $orientador = Orientador::find($estagio->orientador_id);

        $cursos = Curso::all();
        $empresas = Empresa::all();
        $orientadores = Orientador::all();

        return view('estagiario.dados.estagio.show' , [
            "estagio" => $estagio, "curso_aluno" => $curso, "empresa_aluno" => $empresa, "orientador_aluno" => $orientador,
            'cursos' => $cursos, 'empresas' => $empresas, 'orientadores' => $orientadores
        ]);
    }

    //Apagar registro do banco
    public function destroy($id){
        return dd('Apagar registro');
    }

    public function getAluno(){
        $data_aluno = Auth::user()->id;
        $aluno = Aluno::where('usuario_id', $data_aluno)->get()->first();

        return $data_aluno;
    }

    public function updateStatus($id){
        $estagio = Estagio::where('id', $id)->get()->first();

        $estagio->status += 1;

        $estagio->update();

        return back()->with('session', 'Estapa atualizada');
    }
}
