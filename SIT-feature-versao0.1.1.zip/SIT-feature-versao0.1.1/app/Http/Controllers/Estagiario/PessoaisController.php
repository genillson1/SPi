<?php

namespace App\Http\Controllers\Estagiario;

use App\Models\{
    Aluno,
    Endereco,
    User,
};
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PessoaisController extends Controller
{
    //Pagina inicial do crud
    public function index(){
        return dd('Pagina inicial');
    }

    //Pagina com formulario
    public function create(){
        $usuario_id = $this->getAluno();
        
        try {
            $aluno = Aluno::where('usuario_id', $usuario_id)->first();
            $endereco = Endereco::get()->where('id', $aluno->endereco_id)->first();
            if(session('session')){
                return view('estagiario.dados.pessoais.create')->with('session', 'Dados gravados com sucesso');
            }
            return redirect()->route('estagiario.dados.pessoais.edit');
        } catch (\Exception $e) {
            return view('estagiario.dados.pessoais.create');
        }
    }

    //gravação dos dados no banco
    public function store(Request $request){
        $usuario_id = $this->getAluno();
        $data_endereco = $request->only([
            'logradouro', 'numero', 'bairro', 'cep', 'cidade', 'uf'
        ]);
        
        $data_aluno = $request->only([
            'nome', 'cpf', 'rg', 'org_ex', 'data_nascimento', 'email', 'telefone', 'usuario_id', 'endereco_id'
        ]);
        
        try {
            $endereco = Endereco::create($data_endereco);
            $data_aluno['endereco_id'] = $endereco->id;
            $dados = $this->FormatCpf($request->cpf, $request->rg, $request->telefone);
            $data_aluno['usuario_id'] = $usuario_id;
            $data_aluno['cpf'] = $dados['cpf'];
            $data_aluno['rg'] = $dados['rg'];
            $data_aluno['telefone'] = $dados['telefone'];
            $aluno = Aluno::create($data_aluno);
            // dd($data_aluno);
            return back()->with('session', 'Dados gravados com sucesso');
        } catch(\Exception $exception){
            return redirect()->back()->withErrors(['error' => 'Preencha todos os campos']);
        }
    }

    //Pagina com formulario para edição
    public function edit(){
        $user_id = Auth::user()->id;
        $aluno = Aluno::get()->where('usuario_id', $user_id)->first();
        $endereco = Endereco::get()->where('id', $aluno->endereco_id)->first();

        return view('estagiario.dados.pessoais.edit', ['aluno' => $aluno, 'endereco' => $endereco]);
    }

    //Gravação das alterações no banco
    public function update(Request $request){
        $user_id = Auth::user()->id;
        $aluno = Aluno::get()->where('usuario_id', $user_id)->first();
        $endereco = Endereco::get()->where('id', $aluno->endereco_id)->first();

        $data_endereco = $request->only([
            'logradouro', 'numero', 'bairro', 'cep', 'cidade', 'uf'
        ]);

        try {
            $endereco->update($data_endereco);

            $data_aluno = $request->only([
                'nome', 'cpf', 'rg', 'org_ex', 'data_nascimento', 'email', 'telefone'
            ]);
            $dados = $this->FormatCpf($request->cpf, $request->rg, $request->telefone);
            $data_aluno['cpf'] = $dados['cpf'];
            $data_aluno['rg'] = $dados['rg'];
            $data_aluno['telefone'] = $dados['telefone'];
            $aluno->update($data_aluno);

            return back()->with('session', 'Dados Atualizados');
        } catch (\Exception $exception) {
            return back()->withErrors(['error' => 'Não foi possivel Atualizados']);
        }
    }

    //Visualização de registro especifico
    public function show($id){
        $user_id = Auth::user()->id;
        $aluno = Aluno::get()->where('usuario_id', $user_id)->first();
        $endereco = Endereco::get()->where('id', $aluno->endereco_id)->first();

        return view('estagiario.dados.pessoais.show', ['aluno' => $aluno, 'endereco' => $endereco]);
    }

    //Apagar registro do banco
    public function destroy($id){
        return dd('Apagar registro');
    }

    public function FormatCpf($requestCpf, $requestRg, $requestTelefone){
        // Extrai somente os números
        $cpf = preg_replace( '/[^0-9]/is', '', $requestCpf );
        $rg = preg_replace( '/[^0-9]/is', '', $requestRg );
        $telefone = preg_replace( '/[^0-9]/is', '', $requestTelefone );
        $dados = ['cpf' => $cpf, 'rg' => $rg, 'telefone' => $telefone];
        return $dados;
    }

    public function getAluno(){
        $data_aluno = Auth::user()->id;
        $aluno = Aluno::where('usuario_id', $data_aluno)->get()->first();

        return $data_aluno;
    }
}
