<?php

namespace App\Http\Controllers\Estagiario;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use PDF;
use App\Models\{
    Empresa,
    Representante,
    Estagio,
    Endereco,
    Aluno,
    Curso,
    Orientador,
};

class PDFController extends Controller
{
    public function pdf($id){
        $aluno_id = Auth::user()->id;
        $estagio = Estagio::get()->where('id', $id)->first();
        $empresa = Empresa::find($estagio->empresa_id);
        $representante = Representante::get()->where('empresa_id', $empresa->id)->first();
        $endereco_empresa = Endereco::get()->where('id', $empresa->endereco_id)->first();
        $aluno = Aluno::where('usuario_id', $aluno_id)->get()->first();
        $endereco_aluno = Endereco::find($aluno->endereco_id);
        $curso_aluno = Curso::find($estagio->curso_id);
        $orientador = Orientador::find($estagio->orientador_id);

        $dompdf = PDF::loadView('estagiario.dados.termo.pdf', [
            'estagio' => $estagio, 'empresa' => $empresa, 'representante' => $representante, 'endereco_empresa' => $endereco_empresa,
            'endereco_aluno' => $endereco_aluno, 'aluno' => $aluno, 'curso_aluno' => $curso_aluno, 'orientador' => $orientador,
        ])
        ->setPaper('a4')
        ->stream();

        
        try {
            return $dompdf;
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function pdfView($id){
        $aluno_id = Auth::user()->id;
        $estagio = Estagio::get()->where('id', $id)->first();
        $empresa = Empresa::find($estagio->empresa_id);
        $representante = Representante::get()->where('empresa_id', $empresa->id)->first();
        $endereco_empresa = Endereco::get()->where('id', $empresa->endereco_id)->first();
        $aluno = Aluno::where('usuario_id', $aluno_id)->get()->first();
        $endereco_aluno = Endereco::find($aluno->endereco_id);
        $curso_aluno = Curso::find($estagio->curso_id);
        $orientador = Orientador::find($estagio->orientador_id);

        return view('estagiario.dados.termo.pdf', [
            'estagio' => $estagio, 'empresa' => $empresa, 'representante' => $representante, 'endereco_empresa' => $endereco_empresa,
            'endereco_aluno' => $endereco_aluno, 'aluno' => $aluno, 'curso_aluno' => $curso_aluno, 'orientador' => $orientador,
        ]);
    }
}
