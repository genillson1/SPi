<?php

namespace App\Http\Controllers;

use App\Models\{
    User,
    Curso,
    Empresa,
    Orientador,
    Estagio,
    Aluno,
};
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
class AdministrativoController extends Controller
{
    public function AdministrativoIndex(){
        $numero_empresa = Empresa::get()->count();
        $numero_orientador = Orientador::get()->count();
        $numero_curso = Curso::get()->count();
        $numero_estagio = Estagio::get()->count();

        $users = User::get();

        return view('administrativo.index', [
            "users" => $users, "numero_empresa" => $numero_empresa, "numero_orientador" => $numero_orientador, 
            "numero_curso" => $numero_curso, "numero_estagio" => $numero_estagio
        ]);
    }

}
