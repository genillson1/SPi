<?php

namespace App\Http\Controllers;

use App\Models\{
    Curso,
    Empresa,
    Orientador,
    Estagio,
    Aluno,
};
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class EstagiarioController extends Controller
{
    public function EstagiarioIndex(){
        $numero_empresa = Empresa::get()->count();
        $numero_orientador = Orientador::get()->count();
        $numero_curso = Curso::get()->count();
        $numero_estagio = Estagio::get()->count();

        $estagios = DB::table('alunos')
            ->join('estagios', 'alunos.usuario_id', '=', 'estagios.aluno_id')
            ->join('empresas', 'estagios.empresa_id', '=', 'empresas.id')
            ->join('cursos', 'estagios.curso_id', '=', 'cursos.id')
            ->join('orientadors', 'estagios.orientador_id', '=', 'orientadors.id')
            ->select('estagios.id', 'estagios.status','alunos.nome as nome_aluno', 'cursos.nome as nome_curso', 'empresas.nome as nome_empresa', 'orientadors.nome as nome_orientador')
            ->get();
            // dd($aluno);
            // $estagios = Estagio::get();

        return view('estagiario.index', [
            "estagios" => $estagios, "numero_empresa" => $numero_empresa, "numero_orientador" => $numero_orientador, 
            "numero_curso" => $numero_curso, "numero_estagio" => $numero_estagio
        ]);
    }
}
