<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Estagio extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'periodo_curso',
        'data_inicio',
        'data_termino',
        'duracao',
        'status',
        'nome_supervisor',
        'cargo_supervisor',
        'email_supervisor',
        'telefone_supervisor',
        'aluno_id',
        'curso_id',
        'orientador_id',
        'empresa_id',
    ];
}
