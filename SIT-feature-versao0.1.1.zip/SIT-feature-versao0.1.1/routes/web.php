<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Administrativo\{
    CursoController,
    EmpresaController,
    EstudanteController,
    OrientadorController,
};

use App\Http\Controllers\Gestao\{
    CampusController,
    InstituicaoController,
};

use App\Http\Controllers\Estagiario\{
    EstagioController,
    PessoaisController,
    PDFController,
};

use App\Http\Controllers\{
    AdministrativoController,
    EstagiarioController,
};

use App\Http\Controllers\login\LoginController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Área principal
//A principio seria a uma view esplicativa do sistema
//Que averia o redirecionamento para área de login
//Ou redirecionar para área de cadastro
//Rota para pagina inicial do sistema
Route::get('/', function(){
    return view('index');
})->name('inicio');

//Rota de direcionamento direto para o login
Route::get('/', function () {
    return redirect()->route('login.index');
});

//Rota de direcionamento para Cadastro

Route::get('/register', function() {
    return view('login.register');
})->name('index');

//Área Gestão
Route::prefix('/gestao')->name('gestao.')->group(function(){
    //Crud campus
    Route::prefix('/campus')->name('campus.')->group(function(){
        Route::get('/', [CampusController::class, 'index'])->name('index');
        Route::get('/show/{id}', [CampusController::class, 'show'])->name('show');
        Route::get('/create', [CampusController::class, 'create'])->name('create');
        Route::post('/store', [CampusController::class, 'store'])->name('store');
        Route::get('/edit/{id}', [CampusController::class, 'edit'])->name('edit');
        Route::put('/update/{id}', [CampusController::class, 'update'])->name('update');
        Route::delete('/destroy', [CampusController::class, 'destroy'])->name('destroy');
    });

    //Crud instituicao
    Route::prefix('/instituicao')->name('instituicao.')->group(function(){
        Route::get('/', [InstituicaoController::class, 'index'])->name('index');
        Route::get('/show/{id}', [InstituicaoController::class, 'show'])->name('show');
        Route::get('/create', [InstituicaoController::class, 'create'])->name('create');
        Route::post('/store', [InstituicaoController::class, 'store'])->name('store');
        Route::get('/edit/{id}', [InstituicaoController::class, 'edit'])->name('edit');
        Route::put('/update/{id}', [InstituicaoController::class, 'update'])->name('update');
        Route::delete('/destroy', [InstituicaoController::class, 'destroy'])->name('destroy');
    });

    Route::get('/', function(){
        return view('gestao.index');
    })->name('index');
});

//Área administrativa
Route::prefix('/administrativo')->name('administrativo.')->group(function(){
    //Crud Empresa
    Route::prefix('/empresa')->name('empresa.')->group(function(){
        Route::get('/', [EmpresaController::class, 'index'])->name('index');
        Route::get('/show/{id}', [EmpresaController::class, 'show'])->name('show');
        Route::get('/create', [EmpresaController::class, 'create'])->name('create');
        Route::post('/store', [EmpresaController::class, 'store'])->name('store');
        Route::get('/edit/{id}', [EmpresaController::class, 'edit'])->name('edit');
        Route::put('/update/{id}', [EmpresaController::class, 'update'])->name('update');
        Route::post('/destroy', [EmpresaController::class, 'destroy'])->name('destroy');
    });

    //Crud usuario
    Route::prefix('/estudante')->name('estudante.')->group(function(){
        Route::get('/', [EstudanteController::class, 'index'])->name('index');
        Route::get('/show/{id}', [EstudanteController::class, 'show'])->name('show');
        Route::get('/create', [EstudanteController::class, 'create'])->name('create');
        Route::post('/store', [EstudanteController::class, 'store'])->name('store');
        Route::get('/edit/{id}', [EstudanteController::class, 'edit'])->name('edit');
        Route::put('/update/{id}', [EstudanteController::class, 'update'])->name('update');
        Route::post('/destroy', [EstudanteController::class, 'destroy'])->name('destroy');
        Route::get('/pdf/{id}', [PDFController::class, 'pdf'])->name('pdf');
    });

    //Crud curso
    Route::prefix('/curso')->name('curso.')->group(function(){
        Route::get('/', [CursoController::class, 'index'])->name('index');
        Route::get('/show/{id}', [CursoController::class, 'show'])->name('show');
        Route::get('/create', [CursoController::class, 'create'])->name('create');
        Route::post('/store', [CursoController::class, 'store'])->name('store');
        Route::get('/edit/{id}', [CursoController::class, 'edit'])->name('edit');
        Route::put('/update/{id}', [CursoController::class, 'update'])->name('update');
        Route::post('/destroy', [CursoController::class, 'destroy'])->name('destroy');
    });

    //Crud Orientador
    Route::prefix('/orientador')->name('orientador.')->group(function(){
        Route::get('/', [OrientadorController::class, 'index'])->name('index');
        Route::get('/show/{id}', [OrientadorController::class, 'show'])->name('show');
        Route::get('/create', [OrientadorController::class, 'create'])->name('create');
        Route::post('/store', [OrientadorController::class, 'store'])->name('store');
        Route::get('/edit/{id}', [OrientadorController::class, 'edit'])->name('edit');
        Route::put('/update/{id}', [OrientadorController::class, 'update'])->name('update');
        Route::post('/destroy', [OrientadorController::class, 'destroy'])->name('destroy');
    });

    //Visualização dos estagios em andamento
    Route::prefix('/estagio')->name('estagio.')->group(function(){
        Route::get('/', [EstagioController::class, 'index'])->name('index');
        Route::get('/show/{id}', [EstagioController::class, 'show'])->name('show');
        Route::get('/create', [EstagioController::class, 'create'])->name('create');
        Route::post('/store', [EstagioController::class, 'store'])->name('store');
        Route::get('/edit/{id}', [EstagioController::class, 'edit'])->name('edit');
        Route::put('/update/{id}', [EstagioController::class, 'update'])->name('update');
        Route::delete('/destroy', [EstagioController::class, 'destroy'])->name('destroy');
        Route::get('/update/status/{id}', [EstagioController::class, 'updateStatus'])->name('updateStatus');
    });
    //Painel de controle da administração
    Route::get('/', [AdministrativoController::class, 'AdministrativoIndex'])->name('index');
});

//Área do Usuario (Estágiario)
Route::prefix('/estagiario')->name('estagiario.')->group(function(){
    //Cruds para o estagiario
    Route::prefix('/dados')->name('dados.')->group(function(){
        //Crud de dados pessoais
        Route::prefix('/pessoais')->name('pessoais.')->group(function(){
            Route::get('/', [PessoaisController::class, 'index'])->name('index');
            Route::get('/show', [PessoaisController::class, 'show'])->name('show');
            Route::get('/create', [PessoaisController::class, 'create'])->name('create');
            Route::post('/store', [PessoaisController::class, 'store'])->name('store');
            Route::get('/edit', [PessoaisController::class, 'edit'])->name('edit');
            Route::put('/update', [PessoaisController::class, 'update'])->name('update');
            Route::delete('/destroy', [PessoaisController::class, 'destroy'])->name('destroy');
        });

        //Crud para dados do estágio
        Route::prefix('/estagio')->name('estagio.')->group(function(){
            Route::get('/', [EstagioController::class, 'index'])->name('index');
            Route::get('/show/{id}', [EstagioController::class, 'show'])->name('show');
            Route::get('/create', [EstagioController::class, 'create'])->name('create');
            Route::post('/store', [EstagioController::class, 'store'])->name('store');
            Route::get('/edit', [EstagioController::class, 'edit'])->name('edit');
            Route::put('/update', [EstagioController::class, 'update'])->name('update');
            Route::delete('/destroy', [EstagioController::class, 'destroy'])->name('destroy');
        });

        Route::get('/pdf/{id}', [PDFController::class, 'pdf'])->name('pdf');
        Route::get('/pdf/view/{id}', [PDFController::class, 'pdfView'])->name('pdfView');
    });

    Route::get('/', [EstagiarioController::class, 'EstagiarioIndex'])->name('index');
    //Pagina inicial do estágiario
    // Route::get('/', function(){
    //     return view('estagiario.index');
    // })->name('index');

    //Gerar o pdf
    Route::get('/pdf', function(){
        return null;
    })->name('pdf');
});

//Área de login
Route::prefix('/login')->name('login.')->group(function(){
    //Crud de usuário
    Route::prefix('/cadastro')->name('cadastro.')->group(function(){
        return null;
    });

     //Página de login
    Route::get('/', [LoginController::class, 'index'])->name('index');
    Route::post('/entrar', [LoginController::class, 'login'])->name('login');

    Route::get('/create', [LoginController::class, 'create'])->name('create');
    Route::post('/store', [LoginController::class, 'store'])->name('store');
    Route::get('/verification/{id}', [LoginController::class, 'verification'])->name('verification');
    Route::get('/logout', [LoginController::class, 'logout'])->name('logout');

    //  Route::get('/verification', function(){
    //     Mail::to('mozarjunior97@gmail.com')->send(new Verification);
    //  })->name('verification');
});