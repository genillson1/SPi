<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('estagios', function (Blueprint $table) {
            $table->id();
            $table->string('periodo_curso');
            $table->date('data_inicio');
            $table->date('data_termino');
            $table->string('duracao');
            $table->string('status');
            $table->string('nome_supervisor');
            $table->string('cargo_supervisor');
            $table->string('email_supervisor');
            $table->string('telefone_supervisor');
            $table->foreignId('aluno_id');
            $table->foreignId('curso_id');
            $table->foreignId('orientador_id');
            $table->foreignId('empresa_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('estagios');
    }
};
