<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class ProfessorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('orientadors')->insert([
            'nome' => 'Adeísa Guimarães Carvalho',
            'email' => 'adeisa.guimaraes@ifsertao-pe.edu.br',
        ]);
        DB::table('orientadors')->insert([
            'nome' => 'Adriana de Carvalho Figueiredo',
            'email' => 'adriana.figueiredo@ifsertao-pe.edu.br',
        ]);
        DB::table('orientadors')->insert([
            'nome' => 'Ailton Leite Rocha',
            'email' => 'ailton.rocha@ifsertao-pe.edu.br',
        ]);
        DB::table('orientadors')->insert([
            'nome' => 'Alberta Cristina Vasconcelos de Melo',
            'email' => 'alberta.melo@ifsertao-pe.edu.br',
        ]);
        DB::table('orientadors')->insert([
            'nome' => 'André Luiz Santos Patriota',
            'email' => 'andre.patriota@ifsertao-pe.edu.br',
        ]);
        DB::table('orientadors')->insert([
            'nome' => 'Camila Macêdo Medeiros',
            'email' => 'camila.medeiros@ifsertao-pe.edu.br',
        ]);
        DB::table('orientadors')->insert([
            'nome' => 'Cristiane Ayala de Oliveira Leães',
            'email' => 'cristiane.ayala@ifsertao-pe.edu.br',
        ]);
        DB::table('orientadors')->insert([
            'nome' => 'Edmilson Gomes da Silva',
            'email' => 'edmilson.gomes@ifsertao-pe.edu.br',
        ]);
        DB::table('orientadors')->insert([
            'nome' => 'Eriverton da Silva Rodrigues',
            'email' => 'eriverton.rodrigues@ifsertao-pe.edu.br',
        ]);
        DB::table('orientadors')->insert([
            'nome' => 'Francenila Rodrigues Júnior Souza',
            'email' => 'francenila.rodrigues@ifsertao-pe.edu.br',
        ]);
        DB::table('orientadors')->insert([
            'nome' => 'Francisco Junio da Silva Fernandes',
            'email' => 'Francisco.fernandes@ifsertao-pe.edu.br',
        ]);
    }
}
