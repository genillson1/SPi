<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class CursosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('cursos')->insert([
            'nome' => 'Medio Integrado - Edificações',
            'modalidade' => 'Tecnólogos',
            'periodo' => '4',
        ]);
        DB::table('cursos')->insert([
            'nome' => 'Medio integrado - Informatica',
            'modalidade' => 'Tecnólogos',
            'periodo' => '4',
        ]);
        DB::table('cursos')->insert([
            'nome' => 'Subsequente - Agropecuaria',
            'modalidade' => 'Tecnólogos',
            'periodo' => '4',
        ]);
        DB::table('cursos')->insert([
            'nome' => 'Subsequente - Edificações',
            'modalidade' => 'Tecnólogos',
            'periodo' => '4',
        ]);
        DB::table('cursos')->insert([
            'nome' => 'Proeja - Edificações',
            'modalidade' => 'Tecnólogos',
            'periodo' => '4',
        ]);
        DB::table('cursos')->insert([
            'nome' => 'Superior - Sistemas Para Internet',
            'modalidade' => 'Tecnólogos',
            'periodo' => '6',
        ]);
        DB::table('cursos')->insert([
            'nome' => 'Superior - Tecnologia em alimentos',
            'modalidade' => 'Tecnólogos',
            'periodo' => '8',
        ]);
        DB::table('cursos')->insert([
            'nome' => 'Superior - Licenciatura em Fisica',
            'modalidade' => 'Tecnólogos',
            'periodo' => '8',
        ]);
    }
}
